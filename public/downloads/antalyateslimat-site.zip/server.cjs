var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server.ts
var server_exports = {};
__export(server_exports, {
  MAX_ORDER_EMAIL_AGE_MS: () => MAX_ORDER_EMAIL_AGE_MS,
  getOrderNotificationRecipients: () => getOrderNotificationRecipients,
  isTestOrFakeOrder: () => isTestOrFakeOrder,
  maskEmailAddress: () => maskEmailAddress,
  maskEmailCustomerName: () => maskEmailCustomerName,
  maskEmailPhoneNumber: () => maskEmailPhoneNumber
});
module.exports = __toCommonJS(server_exports);
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_os = __toESM(require("os"), 1);
var import_https = __toESM(require("https"), 1);
var import_events = require("events");
var import_vite = require("vite");
var import_nodemailer = __toESM(require("nodemailer"), 1);
var import_app = require("firebase/app");
var import_firestore = require("firebase/firestore");
var import_genai = require("@google/genai");
var import_node_edge_tts = require("node-edge-tts");
process.on("uncaughtException", (err) => {
  console.error("[UNCAUGHT EXCEPTION]", err);
});
process.on("unhandledRejection", (reason) => {
  console.error("[UNHANDLED REJECTION]", reason);
});
var app = (0, import_express.default)();
var PORT = 3e3;
if (process.env.PORT) {
  PORT = parseInt(process.env.PORT, 10);
} else {
  const portArgIndex = process.argv.indexOf("--port");
  if (portArgIndex !== -1 && process.argv[portArgIndex + 1]) {
    PORT = parseInt(process.argv[portArgIndex + 1], 10);
  }
}
var geminiClient = null;
if (process.env.GEMINI_API_KEY) {
  try {
    geminiClient = new import_genai.GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
    console.log("[GEMINI AI] GoogleGenAI client initialized on server.");
  } catch (err) {
    console.warn("[GEMINI AI] Failed to initialize GoogleGenAI:", err.message);
  }
}
var serverFirebaseConfig = {
  projectId: "ringed-block-jdw25",
  appId: "1:120490913482:web:81205548e8707e5c17ce33",
  apiKey: "AIzaSyA0LZDucLLGbpPcRitRqpdMg1v6D1Epgwo",
  authDomain: "ringed-block-jdw25.firebaseapp.com",
  firestoreDatabaseId: "ai-studio-antalyakuryeexpr-2c4fd8fd-f44c-4d53-ad73-e640951dadc7"
};
var serverFirestoreDb = null;
try {
  const fbApp = !(0, import_app.getApps)().length ? (0, import_app.initializeApp)(serverFirebaseConfig) : (0, import_app.getApp)();
  serverFirestoreDb = serverFirebaseConfig.firestoreDatabaseId ? (0, import_firestore.getFirestore)(fbApp, serverFirebaseConfig.firestoreDatabaseId) : (0, import_firestore.getFirestore)(fbApp);
  console.log("[FIREBASE BACKEND] Direct Firestore instance connected successfully.");
} catch (fbErr) {
  console.warn("[FIREBASE BACKEND] Direct Firestore connection warning:", fbErr.message);
}
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, PATCH, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
  if (req.method === "OPTIONS") {
    res.sendStatus(200);
    return;
  }
  next();
});
app.use(import_express.default.json({ limit: "10mb" }));
app.use(import_express.default.urlencoded({ extended: true }));
app.get("/google1ef8290a0908c9ac.html", (req, res) => {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.send("google-site-verification: google1ef8290a0908c9ac.html");
});
var DATA_DIR = import_path.default.join(process.cwd(), "data");
var DB_FILE = import_path.default.join(DATA_DIR, "server-db.json");
var DEFAULT_USERS = [
  {
    id: "user-guest-01",
    name: "Misafir M\xFC\u015Fteri",
    phone: "",
    email: "",
    password: "",
    role: "customer",
    district: "Muratpa\u015Fa",
    createdAt: "2026-01-01T00:00:00.000Z"
  },
  {
    id: "user-admin-01",
    name: "Antalya Kurye Y\xF6netim",
    phone: "0507 754 74 84",
    email: "kuryeantalyam@gmail.com",
    password: "admin",
    role: "admin",
    companyName: "Antalya Kurye Express",
    district: "Muratpa\u015Fa",
    createdAt: "2026-01-01T00:00:00.000Z"
  },
  {
    id: "user-courier-1787999333451",
    name: "Kurye \xDCmit",
    phone: "0123456789",
    email: "cantalyacanta@gmail.com",
    password: "666",
    role: "courier",
    district: "Muratpa\u015Fa",
    createdAt: "2026-08-29T10:28:53.451Z",
    totalOrders: 10,
    totalEarnings: 890,
    isOnline: true
  }
];
var DEFAULT_COURIERS = [
  {
    id: "user-courier-1787999333451",
    name: "Kurye \xDCmit",
    phone: "0123456789",
    email: "cantalyacanta@gmail.com",
    district: "Muratpa\u015Fa",
    rating: 5,
    totalDeliveries: 10,
    currentLat: 36.886,
    currentLng: 30.7065,
    isOnline: true
  }
];
var getTodayDateStr = () => (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
var DEFAULT_VISITOR_STATS = {
  totalVisits: 0,
  uniqueVisitors: 0,
  todayVisits: 0,
  todayDate: getTodayDateStr(),
  uniqueVisitorIds: [],
  todayVisitorIds: [],
  lastVisitAt: (/* @__PURE__ */ new Date()).toISOString(),
  recentVisitors: []
};
var DEFAULT_SMTP_CONFIG = {
  service: "gmail",
  host: "smtp.gmail.com",
  port: 587,
  secure: false,
  user: "kuryeantalyam@gmail.com",
  pass: "tlnsrezkaobytsvg",
  fromName: "Antalya \u015Eehir \u0130\xE7i Teslimat 7/24",
  fromEmail: "kuryeantalyam@gmail.com",
  enabled: true,
  newOrderEmailsEnabled: true,
  lastTestedAt: (/* @__PURE__ */ new Date()).toISOString(),
  lastTestStatus: "success",
  lastTestMessage: "Gmail SMTP ba\u011Flant\u0131s\u0131 haz\u0131rland\u0131 (kuryeantalyam@gmail.com)."
};
var dbState = {
  users: DEFAULT_USERS,
  couriers: DEFAULT_COURIERS,
  requests: [],
  emailLogs: [],
  extraCourierEmails: [],
  visitorStats: { ...DEFAULT_VISITOR_STATS },
  smtpConfig: { ...DEFAULT_SMTP_CONFIG },
  updatedAt: (/* @__PURE__ */ new Date()).toISOString()
};
function ensureDataDir() {
  try {
    if (!import_fs.default.existsSync(DATA_DIR)) {
      import_fs.default.mkdirSync(DATA_DIR, { recursive: true });
    }
  } catch (err) {
    console.error("Failed to create data directory:", err);
  }
}
function loadDatabase() {
  ensureDataDir();
  try {
    if (import_fs.default.existsSync(DB_FILE)) {
      const data = import_fs.default.readFileSync(DB_FILE, "utf-8");
      const parsed = JSON.parse(data);
      if (parsed && Array.isArray(parsed.users) && Array.isArray(parsed.requests)) {
        const userMap = /* @__PURE__ */ new Map();
        DEFAULT_USERS.forEach((u) => userMap.set(u.id, u));
        parsed.users.forEach((u) => userMap.set(u.id, { ...userMap.get(u.id) || {}, ...u }));
        const courierMap = /* @__PURE__ */ new Map();
        DEFAULT_COURIERS.forEach((c) => courierMap.set(c.id, c));
        if (Array.isArray(parsed.couriers)) {
          parsed.couriers.forEach((c) => courierMap.set(c.id, { ...courierMap.get(c.id) || {}, ...c }));
        }
        const cleanRequests = parsed.requests.filter(
          (r) => r && r.id && !String(r.id).startsWith("req-sample-") && !String(r.id).startsWith("req-test-") && !String(r.id).startsWith("test-") && r.trackingCode !== "ANT-5892" && r.trackingCode !== "ANT-9999"
        );
        const existingSmtp = parsed.smtpConfig || {};
        const savedPass = existingSmtp.pass && existingSmtp.pass.trim() !== "" ? existingSmtp.pass : "tlnsrezkaobytsvg";
        const smtpCfg = {
          service: existingSmtp.service || "gmail",
          host: existingSmtp.host || "smtp.gmail.com",
          port: Number(existingSmtp.port) || 587,
          secure: Boolean(existingSmtp.secure),
          user: existingSmtp.user || "kuryeantalyam@gmail.com",
          pass: savedPass,
          fromName: existingSmtp.fromName || "Antalya \u015Eehir \u0130\xE7i Teslimat 7/24",
          fromEmail: existingSmtp.fromEmail || "kuryeantalyam@gmail.com",
          enabled: existingSmtp.enabled !== false,
          newOrderEmailsEnabled: existingSmtp.newOrderEmailsEnabled !== false,
          lastTestedAt: existingSmtp.lastTestedAt || (/* @__PURE__ */ new Date()).toISOString(),
          lastTestStatus: existingSmtp.lastTestStatus || "success",
          lastTestMessage: existingSmtp.lastTestMessage || "Gmail SMTP ba\u011Flant\u0131s\u0131 haz\u0131r."
        };
        const savedStats = parsed.visitorStats || {};
        const todayStr = getTodayDateStr();
        const isNewDay = savedStats.todayDate !== todayStr;
        const currentVisitorStats = {
          totalVisits: typeof savedStats.totalVisits === "number" ? savedStats.totalVisits : 0,
          uniqueVisitors: typeof savedStats.uniqueVisitors === "number" ? savedStats.uniqueVisitors : 0,
          todayVisits: isNewDay ? 0 : typeof savedStats.todayVisits === "number" ? savedStats.todayVisits : 0,
          todayDate: todayStr,
          uniqueVisitorIds: Array.isArray(savedStats.uniqueVisitorIds) ? savedStats.uniqueVisitorIds : [],
          todayVisitorIds: isNewDay ? [] : Array.isArray(savedStats.todayVisitorIds) ? savedStats.todayVisitorIds : [],
          lastVisitAt: savedStats.lastVisitAt || (/* @__PURE__ */ new Date()).toISOString(),
          recentVisitors: Array.isArray(savedStats.recentVisitors) ? savedStats.recentVisitors : []
        };
        dbState = {
          users: Array.from(userMap.values()),
          couriers: Array.from(courierMap.values()),
          requests: cleanRequests,
          emailLogs: Array.isArray(parsed.emailLogs) ? parsed.emailLogs : [],
          extraCourierEmails: Array.isArray(parsed.extraCourierEmails) ? parsed.extraCourierEmails : [],
          smtpConfig: smtpCfg,
          visitorStats: currentVisitorStats,
          updatedAt: parsed.updatedAt || (/* @__PURE__ */ new Date()).toISOString()
        };
        console.log(`[DB] Database loaded successfully: ${dbState.requests.length} requests, ${dbState.users.length} users, ${dbState.visitorStats.totalVisits} visits logged`);
        return;
      }
    }
  } catch (err) {
    console.warn("[DB] Failed to load database file, using default state:", err);
  }
  saveDatabase();
}
function saveDatabase() {
  ensureDataDir();
  try {
    dbState.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    import_fs.default.writeFileSync(DB_FILE, JSON.stringify(dbState, null, 2), "utf-8");
  } catch (err) {
    console.error("[DB] Failed to save database to disk:", err);
  }
}
loadDatabase();
var dispatchedEmailOrderIds = /* @__PURE__ */ new Set();
if (Array.isArray(dbState.requests)) {
  dbState.requests.forEach((r) => {
    if (r.emailDispatched) {
      if (r.id) dispatchedEmailOrderIds.add(r.id);
      if (r.trackingCode) dispatchedEmailOrderIds.add(r.trackingCode);
    }
  });
}
var MAX_ORDER_EMAIL_AGE_MS = 20 * 60 * 1e3;
function isTestOrFakeOrder(order) {
  if (!order || typeof order !== "object") return true;
  if (order.isTest === true) return true;
  const id = String(order.id || "").toLowerCase().trim();
  const tracking = String(order.trackingCode || "").toUpperCase().trim();
  const senderName = String(order.sender?.contactName || "").toLowerCase().trim();
  const receiverName = String(order.receiver?.contactName || "").toLowerCase().trim();
  const senderPhone = String(order.sender?.contactPhone || "").replace(/\D/g, "");
  const receiverPhone = String(order.receiver?.contactPhone || "").replace(/\D/g, "");
  const pkgName = String(order.packageName || "").toLowerCase().trim();
  const note = String(order.noteForCourier || "").toLowerCase().trim();
  if (id.includes("sample") || id.includes("test") || id.includes("verif") || id.includes("dummy") || id.includes("mock") || id.includes("puretext") || id.includes("live-order") || id.includes("live-test")) {
    return true;
  }
  if (tracking.includes("TEST") || tracking.includes("SAMPLE") || tracking.includes("VERIF") || tracking.includes("DEMO") || tracking === "ANT-3333" || tracking === "ANT-5892" || tracking === "ANT-7240" || tracking === "ANT-7788" || tracking === "ANT-9988" || tracking === "ANT-7414" || tracking === "ANT-91827" || tracking === "ANT-6397" || tracking === "ANT-9999" || tracking.startsWith("REF-")) {
    return true;
  }
  const testNames = [
    "test",
    "deneme",
    "\xF6rnek",
    "ornek",
    "murat kara",
    "ay\u015Fe y\u0131ld\u0131r\u0131m",
    "ayse yildirim",
    "ahmet bey",
    "mehmet bey",
    "mustafa kaya",
    "zeynep \xE7elik",
    "zeynep celik",
    "selim bey",
    "serkan bey",
    "zeynep han\u0131m",
    "zeynep hanim",
    "deniz akdeniz (m\xFC\u015Fteri)",
    "test m\xFC\u015Fteri",
    "test al\u0131c\u0131",
    "djsje sks",
    "uu jj",
    "frf"
  ];
  if (testNames.some((t) => senderName.includes(t) || receiverName.includes(t))) {
    return true;
  }
  if (senderName && receiverName && senderName === receiverName) {
    if (senderName.includes("umit") || senderName.includes("\xFCmit") || senderName.includes("test")) {
      return true;
    }
  }
  const dummyPhones = [
    "05000000000",
    "5000000000",
    "05555555555",
    "5555555555"
  ];
  if (dummyPhones.includes(senderPhone) || dummyPhones.includes(receiverPhone)) {
    return true;
  }
  if (pkgName.includes("test") || pkgName.includes("\xF6rnek") || pkgName.includes("deneme")) {
    return true;
  }
  if (note.includes("test ama\xE7l\u0131") || note.includes("test sipari\u015Fi") || note.includes("deneme sipari\u015Fi")) {
    return true;
  }
  return false;
}
function maskEmailCustomerName(name) {
  if (!name || typeof name !== "string" || !name.trim()) {
    return "M***";
  }
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "M***";
  return parts.map((part) => {
    const firstChar = part.charAt(0).toUpperCase();
    return `${firstChar}***`;
  }).join(" ");
}
function maskEmailPhoneNumber(phone) {
  if (!phone || typeof phone !== "string" || !phone.trim() || phone === "Telefon belirtilmedi") {
    return "05** *** ** **";
  }
  let digits = phone.replace(/\D/g, "");
  if (digits.startsWith("90") && digits.length === 12) {
    digits = "0" + digits.slice(2);
  } else if (!digits.startsWith("0") && digits.length === 10) {
    digits = "0" + digits;
  }
  if (digits.length >= 7) {
    const p1 = digits.slice(0, 4);
    const p2 = digits.slice(4, 7);
    return `${p1} ${p2} ** **`;
  }
  return "05** *** ** **";
}
function maskEmailAddress(addr) {
  if (!addr || typeof addr !== "string" || !addr.trim() || addr === "Adres belirtilmedi") {
    return "Adres detay\u0131 gizlenmi\u015Ftir (Kurye g\xF6revi kabul edince a\xE7\u0131l\u0131r)";
  }
  const clean = addr.trim();
  if (clean.length <= 12) {
    return `${clean.slice(0, 4)}*** (Kabul edince a\xE7\u0131l\u0131r)`;
  }
  const visibleLen = Math.min(18, Math.max(8, Math.floor(clean.length * 0.35)));
  return `${clean.slice(0, visibleLen)}... (A\xE7\u0131k Adres & Kap\u0131 No Gizli - Talebi kabul edince a\xE7\u0131l\u0131r)`;
}
function getOrderNotificationRecipients(orderOrIsTest) {
  const isTest = typeof orderOrIsTest === "boolean" ? orderOrIsTest : orderOrIsTest ? isTestOrFakeOrder(orderOrIsTest) : false;
  const recipients = /* @__PURE__ */ new Set();
  recipients.add("kuryeantalyam@gmail.com");
  const adminEmail = (dbState.smtpConfig?.user || "kuryeantalyam@gmail.com").trim().toLowerCase();
  if (adminEmail && adminEmail.includes("@") && adminEmail.includes(".")) {
    recipients.add(adminEmail);
  }
  if (isTest) {
    return Array.from(recipients);
  }
  const addCourierEmail = (raw) => {
    if (!raw || typeof raw !== "string") return;
    const clean = raw.trim().toLowerCase();
    if (clean.length > 5 && clean.includes("@") && clean.includes(".") && !clean.endsWith("@antalyakurye.com") && !clean.endsWith("@example.com") && !clean.includes("example.com") && !clean.includes("deneme")) {
      recipients.add(clean);
    }
  };
  if (Array.isArray(dbState.users)) {
    dbState.users.forEach((u) => {
      if (u && (u.role === "courier" || u.isCourier === true)) {
        addCourierEmail(u.email);
      }
    });
  }
  if (Array.isArray(dbState.couriers)) {
    dbState.couriers.forEach((c) => {
      if (c) {
        addCourierEmail(c.email);
      }
    });
  }
  if (Array.isArray(dbState.extraCourierEmails)) {
    dbState.extraCourierEmails.forEach((em) => {
      addCourierEmail(em);
    });
  }
  return Array.from(recipients);
}
var getRegisteredCourierEmails = getOrderNotificationRecipients;
var emailQueue = [];
var emailQueueEvents = new import_events.EventEmitter();
var isQueueWorkerRunning = false;
var cachedMailTransporter = null;
var lastTransporterConfigKey = "";
function getMailTransporter() {
  const cfg = dbState.smtpConfig;
  const envHost = process.env.SMTP_HOST;
  const envUser = process.env.SMTP_USER || process.env.GMAIL_USER;
  const envPass = process.env.SMTP_PASS || process.env.GMAIL_APP_PASSWORD;
  const user = (cfg?.user || envUser || "kuryeantalyam@gmail.com").trim();
  const pass = (cfg?.pass || envPass || "tlnsrezkaobytsvg").replace(/\s+/g, "").trim();
  const fromName = cfg?.fromName || "Antalya \u015Eehir \u0130\xE7i Teslimat 7/24";
  const fromEmail = cfg?.fromEmail || user || "kuryeantalyam@gmail.com";
  const fromAddress = `"${fromName}" <${fromEmail}>`;
  const isGmail = user.toLowerCase().endsWith("@gmail.com") || cfg?.service === "gmail" || cfg?.host && cfg.host.includes("gmail");
  const host = isGmail ? "smtp.gmail.com" : (cfg?.host || envHost || "smtp.gmail.com").trim();
  const port = isGmail ? 465 : Number(cfg?.port) || 587;
  const secure = port === 465;
  const configKey = `${host}:${port}:${secure}:${user}:${pass}`;
  if (!cachedMailTransporter || lastTransporterConfigKey !== configKey) {
    if (cachedMailTransporter) {
      try {
        cachedMailTransporter.close();
      } catch {
      }
    }
    if (user && pass && cfg?.enabled !== false) {
      cachedMailTransporter = import_nodemailer.default.createTransport({
        pool: true,
        maxConnections: 3,
        maxMessages: 100,
        host,
        port,
        secure,
        auth: { user, pass },
        tls: { rejectUnauthorized: false },
        connectionTimeout: 1e4,
        greetingTimeout: 1e4,
        socketTimeout: 15e3
      });
      lastTransporterConfigKey = configKey;
      console.log(`[SMTP POOL] Initialized high-performance pooled SMTP transport on ${host}:${port} (${user})`);
    } else {
      cachedMailTransporter = null;
      lastTransporterConfigKey = "";
    }
  }
  return { transporter: cachedMailTransporter, fromAddress, isConfigured: Boolean(cachedMailTransporter), user, host };
}
async function processEmailQueue() {
  if (isQueueWorkerRunning) return;
  isQueueWorkerRunning = true;
  try {
    while (true) {
      const job = emailQueue.find((j) => j.status === "pending");
      if (!job) break;
      job.status = "processing";
      job.startedAt = (/* @__PURE__ */ new Date()).toISOString();
      job.attempts += 1;
      const startTime = Date.now();
      console.log(`[ASYNC QUEUE] \u{1F680} Processing job #${job.id} for Order #${job.trackingCode} (Attempt ${job.attempts}/${job.maxAttempts}) to: ${job.recipients.join(", ")}`);
      try {
        const mailDetails = getMailTransporter();
        let emailStatus = "simulated";
        let errorMessage;
        let isRealDelivery = false;
        const sentRecipients = [];
        const failedRecipients = [];
        if (mailDetails.transporter && mailDetails.isConfigured) {
          const primaryRecipients = ["kuryeantalyam@gmail.com", "cantalyacanta@gmail.com"].filter(
            (em) => job.recipients.some((r) => r.toLowerCase() === em.toLowerCase())
          );
          if (primaryRecipients.length === 0) {
            primaryRecipients.push("kuryeantalyam@gmail.com");
          }
          const otherCourierRecipients = job.recipients.filter(
            (r) => !primaryRecipients.includes(r.toLowerCase())
          );
          try {
            const adminInfo = await mailDetails.transporter.sendMail({
              from: mailDetails.fromAddress,
              to: primaryRecipients.join(", "),
              replyTo: "kuryeantalyam@gmail.com",
              subject: job.subject,
              text: job.textContent,
              html: job.htmlContent,
              priority: "high",
              headers: {
                "X-Priority": "1",
                "X-MSMail-Priority": "High",
                "Importance": "high"
              }
            });
            sentRecipients.push(...primaryRecipients);
            console.log(`[ASYNC QUEUE] \u2705 Primary direct dispatch delivered to ${primaryRecipients.join(", ")} in ${Date.now() - startTime}ms. Response: ${adminInfo.response}`);
          } catch (adminErr) {
            console.warn(`[ASYNC QUEUE FAIL] Primary direct dispatch error:`, adminErr.message);
            primaryRecipients.forEach((em) => failedRecipients.push({ email: em, error: adminErr.message || "SMTP iletim hatas\u0131" }));
          }
          if (otherCourierRecipients.length > 0 && !job.isTest) {
            const chunkSize = 25;
            for (let i = 0; i < otherCourierRecipients.length; i += chunkSize) {
              const chunk = otherCourierRecipients.slice(i, i + chunkSize);
              try {
                const bccInfo = await mailDetails.transporter.sendMail({
                  from: mailDetails.fromAddress,
                  to: `"Antalya N\xF6bet\xE7i Kurye Bildirim A\u011F\u0131" <${mailDetails.user}>`,
                  bcc: chunk,
                  replyTo: "kuryeantalyam@gmail.com",
                  subject: job.subject,
                  text: job.textContent,
                  html: job.htmlContent,
                  priority: "high",
                  headers: {
                    "X-Priority": "1",
                    "X-MSMail-Priority": "High",
                    "Importance": "high"
                  }
                });
                sentRecipients.push(...chunk);
                console.log(`[ASYNC QUEUE] \u2705 Courier broadcast chunk (${chunk.length} couriers) delivered. Response: ${bccInfo.response}`);
              } catch (bccErr) {
                console.warn(`[ASYNC QUEUE FAIL] Courier broadcast chunk error:`, bccErr.message);
                chunk.forEach((em) => failedRecipients.push({ email: em, error: bccErr.message || "BCC iletim hatas\u0131" }));
              }
            }
          }
          if (sentRecipients.length > 0) {
            emailStatus = "sent";
            isRealDelivery = true;
            console.log(`[ASYNC QUEUE SUCCESS] Successfully delivered to ${sentRecipients.length} address(es) in ${Date.now() - startTime}ms`);
            if (failedRecipients.length > 0) {
              errorMessage = `K\u0131smi iletim (${sentRecipients.length} ba\u015Far\u0131l\u0131). Hata alanlar: ${failedRecipients.map((f) => f.email).join(", ")}`;
            }
          } else {
            emailStatus = "failed";
            errorMessage = failedRecipients.map((f) => `${f.email}: ${f.error}`).join(" | ");
            throw new Error(errorMessage || "T\xFCm al\u0131c\u0131lara g\xF6nderim ba\u015Far\u0131s\u0131z oldu.");
          }
        } else {
          console.log(`[ASYNC QUEUE SIMULATED] SMTP not configured. Simulated dispatch for ${job.recipients.join(", ")}`);
          emailStatus = "simulated";
          errorMessage = "SMTP e-posta sunucusu veya Gmail \u015Fifresi tan\u0131mlanmad\u0131. Y\xF6netim panelinden yap\u0131land\u0131r\u0131n\u0131z.";
        }
        job.status = emailStatus;
        job.completedAt = (/* @__PURE__ */ new Date()).toISOString();
        job.durationMs = Date.now() - startTime;
        job.isRealDelivery = isRealDelivery;
        if (job.orderId) dispatchedEmailOrderIds.add(job.orderId);
        if (job.trackingCode) dispatchedEmailOrderIds.add(job.trackingCode);
        const order = dbState.requests.find((r) => r.id === job.orderId || r.trackingCode === job.trackingCode);
        if (order) {
          order.emailDispatched = true;
          order.emailDispatchedAt = job.completedAt;
        }
        if (serverFirestoreDb && job.orderId) {
          try {
            const reqDocRef = (0, import_firestore.doc)(serverFirestoreDb, "delivery_requests", job.orderId);
            const docPayload = order ? { ...order, emailDispatched: true, emailDispatchedAt: job.completedAt } : { emailDispatched: true, emailDispatchedAt: job.completedAt };
            (0, import_firestore.setDoc)(reqDocRef, JSON.parse(JSON.stringify(docPayload)), { merge: true }).catch((e) => console.warn("[FIRESTORE UPDATE DISPATCH ERR]", e.message));
          } catch (e) {
            console.warn("[FIRESTORE DOC REF ERR]", e.message);
          }
        }
        const logEntry = {
          id: `mail-${Date.now()}-${Math.floor(Math.random() * 1e3)}`,
          timestamp: job.completedAt,
          orderId: job.orderId,
          trackingCode: job.trackingCode,
          recipients: job.recipients,
          subject: job.subject,
          status: emailStatus,
          error: errorMessage,
          summary: job.subject
        };
        if (!Array.isArray(dbState.emailLogs)) {
          dbState.emailLogs = [];
        }
        dbState.emailLogs.unshift(logEntry);
        if (dbState.emailLogs.length > 100) {
          dbState.emailLogs = dbState.emailLogs.slice(0, 100);
        }
        saveDatabase();
      } catch (jobErr) {
        console.warn(`[ASYNC QUEUE EXCEPTION] Job #${job.id} failed:`, jobErr.message);
        job.error = jobErr.message;
        job.durationMs = Date.now() - startTime;
        if (job.attempts < job.maxAttempts) {
          job.status = "pending";
          console.log(`[ASYNC QUEUE RETRY] Scheduling retry for Job #${job.id} in 2s...`);
          await new Promise((resolve) => setTimeout(resolve, 2e3));
        } else {
          job.status = "failed";
          job.completedAt = (/* @__PURE__ */ new Date()).toISOString();
        }
      }
    }
  } finally {
    isQueueWorkerRunning = false;
  }
}
emailQueueEvents.on("job_enqueued", () => {
  setImmediate(() => {
    processEmailQueue().catch((err) => console.error("[ASYNC QUEUE WORKER CRITICAL]", err));
  });
});
function enqueueNewOrderEmail(order, specificRecipient, isForce = false) {
  const orderId = order.id || "";
  const trackingCode = order.trackingCode || orderId || "ANT-0000";
  const isTest = isTestOrFakeOrder(order);
  const newOrderEmailsEnabled = dbState.smtpConfig?.newOrderEmailsEnabled !== false;
  if (!newOrderEmailsEnabled && !isForce) {
    console.log(`[EMAIL GUARD] \u{1F6AB} Yeni talep mailleri kapal\u0131. #${trackingCode} (${orderId}) i\xE7in kimseye e-posta g\xF6nderilmedi.`);
    order.emailDispatched = true;
    order.emailDispatchedAt = "disabled_by_config";
    if (orderId) dispatchedEmailOrderIds.add(orderId);
    if (trackingCode) dispatchedEmailOrderIds.add(trackingCode);
    return {
      success: true,
      isRealDelivery: false,
      status: "disabled",
      message: "Yeni talep e-posta bildirimleri kapat\u0131lm\u0131\u015Ft\u0131r. Hi\xE7 kimseye e-posta g\xF6nderilmedi."
    };
  }
  if (isTest && !isForce) {
    console.log(`[EMAIL GUARD] \u{1F6AB} Skipping test/fake order #${trackingCode} (${orderId}). No email will be sent.`);
    order.emailDispatched = true;
    order.emailDispatchedAt = "test_skipped";
    if (orderId) dispatchedEmailOrderIds.add(orderId);
    if (trackingCode) dispatchedEmailOrderIds.add(trackingCode);
    return {
      success: true,
      isRealDelivery: false,
      status: "test_skipped",
      message: "Test/sahte talep tespit edildi, e-posta g\xF6nderilmedi."
    };
  }
  const referenceTimeIso = order.approvedAt || order.createdAt;
  if (!isForce && referenceTimeIso) {
    const orderRefTimeMs = new Date(referenceTimeIso).getTime();
    if (!isNaN(orderRefTimeMs)) {
      const ageMs = Date.now() - orderRefTimeMs;
      if (ageMs > MAX_ORDER_EMAIL_AGE_MS) {
        console.log(`[EMAIL GUARD] \u23F0 Stale order #${trackingCode} (${orderId}) created/approved ${Math.round(ageMs / 6e4)}m ago. Skipping email dispatch.`);
        order.emailDispatched = true;
        order.emailDispatchedAt = order.emailDispatchedAt || "stale_skipped";
        if (orderId) dispatchedEmailOrderIds.add(orderId);
        if (trackingCode) dispatchedEmailOrderIds.add(trackingCode);
        return {
          success: true,
          isRealDelivery: false,
          status: "stale_skipped",
          message: "Eski tarihli sipari\u015F i\xE7in e-posta g\xF6nderimi atland\u0131."
        };
      }
    }
  }
  if (order.status === "pending_admin" && !isForce) {
    console.log(`[EMAIL GUARD] \u23F3 Order #${trackingCode} (${orderId}) is waiting for manager approval ('pending_admin'). Skipping courier email until manager approves.`);
    return {
      success: true,
      isRealDelivery: false,
      status: "pending_admin_approval",
      message: "Sipari\u015F y\xF6netici onay\u0131 bekliyor. Kuryelere mail g\xF6nderilmedi."
    };
  }
  if (!isForce) {
    const alreadyDispatched = order.emailDispatched === true || orderId && dispatchedEmailOrderIds.has(orderId) || trackingCode && dispatchedEmailOrderIds.has(trackingCode) || emailQueue.some(
      (j) => (j.orderId === orderId || j.trackingCode === trackingCode) && (j.status === "pending" || j.status === "processing" || j.status === "sent")
    );
    if (alreadyDispatched) {
      console.log(`[ASYNC QUEUE DEDUP] Order ${orderId} (#${trackingCode}) already enqueued or dispatched. Skipping.`);
      return {
        success: true,
        isRealDelivery: false,
        status: "already_sent",
        message: "Bu sipari\u015F i\xE7in bildirim e-postas\u0131 daha \xF6nce s\u0131raya al\u0131nd\u0131 veya g\xF6nderildi."
      };
    }
  }
  let recipients = [];
  if (specificRecipient && specificRecipient.includes("@")) {
    const targetClean = specificRecipient.trim().toLowerCase();
    if (isTest) {
      const isRegisteredCourier = (dbState.users || []).some(
        (u) => u.role === "courier" && u.email && u.email.toLowerCase() === targetClean && targetClean !== "kuryeantalyam@gmail.com"
      );
      if (isRegisteredCourier) {
        console.warn(`[SAFETY] Prevented sending test email to courier ${targetClean}. Diverting to admin.`);
        recipients = ["kuryeantalyam@gmail.com"];
      } else {
        recipients = [targetClean];
      }
    } else {
      recipients = [targetClean];
    }
  } else {
    recipients = getOrderNotificationRecipients(order);
  }
  const senderDist = order.sender?.district || "Antalya";
  const senderNeighborhood = order.sender?.neighborhood ? ` (${order.sender.neighborhood})` : "";
  const senderAddr = order.sender?.addressDetail || order.sender?.address || "Adres belirtilmedi";
  const rawSenderPhone = order.sender?.contactPhone || order.sender?.phone || "Telefon belirtilmedi";
  const rawSenderName = order.sender?.contactName || "M\xFC\u015Fteri";
  const receiverDist = order.receiver?.district || "Antalya";
  const receiverNeighborhood = order.receiver?.neighborhood ? ` (${order.receiver.neighborhood})` : "";
  const receiverAddr = order.receiver?.addressDetail || order.receiver?.address || "Adres belirtilmedi";
  const rawReceiverPhone = order.receiver?.contactPhone || order.receiver?.phone || "Telefon belirtilmedi";
  const rawReceiverName = order.receiver?.contactName || "Al\u0131c\u0131";
  const maskedSenderName = maskEmailCustomerName(rawSenderName);
  const maskedSenderPhone = maskEmailPhoneNumber(rawSenderPhone);
  const maskedSenderAddr = maskEmailAddress(senderAddr);
  const maskedReceiverName = maskEmailCustomerName(rawReceiverName);
  const maskedReceiverPhone = maskEmailPhoneNumber(rawReceiverPhone);
  const maskedReceiverAddr = maskEmailAddress(receiverAddr);
  const packageName = order.packageName || order.packageType || "Standart Paket";
  const price = Number(order.price) || 0;
  const courierEarnings = Number(order.courierEarnings) || Math.round(price * 0.85);
  let paymentMethodLabel = "Al\u0131c\u0131 \xD6demeli (Kap\u0131da Nakit / Havale)";
  if (order.paymentMethod === "sender_paid" || order.paymentMethod === "gonderici_odemeli") {
    paymentMethodLabel = "G\xF6nderici \xD6demeli (Al\u0131rken Tahsil Edilecek)";
  } else if (order.paymentMethod === "online_credit_card" || order.isPaid) {
    paymentMethodLabel = "Online \xD6dendi (Kredi Kart\u0131)";
  } else if (order.paymentMethod === "card_on_delivery") {
    paymentMethodLabel = "Kap\u0131da Kredi Kart\u0131";
  }
  const urgencyLabel = order.urgency === "vip" ? "VIP Acil (30-45 dk)" : order.urgency === "express" ? "Ekspres (45-60 dk)" : "Standart (90-120 dk)";
  const formattedDate = (/* @__PURE__ */ new Date()).toLocaleString("tr-TR", {
    timeZone: "Europe/Istanbul",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
  const rawDistKm = Number(order.estimatedDistanceKm) || 0;
  const approximateDistanceText = rawDistKm > 0 ? `~${rawDistKm} km` : senderDist === receiverDist ? "~5-8 km" : "~12-18 km";
  const subjectPrefix = isTest ? "[TEST B\u0130LD\u0130R\u0130M\u0130 / Y\xD6NET\u0130C\u0130]" : "[YEN\u0130 M\xDC\u015ETER\u0130 TALEB\u0130]";
  const subject = `${subjectPrefix} #${trackingCode} | ${senderDist} \u2794 ${receiverDist} (${approximateDistanceText}) | ${price} TL (${paymentMethodLabel})`;
  const textContent = `
========================================
ANTALYA \u015EEH\u0130R \u0130\xC7\u0130 MOTO KURYE - YEN\u0130 TALEP
========================================
Takip Kodu     : #${trackingCode}
Talep Zaman\u0131   : ${formattedDate}
Durum          : Kurye Havuzunda Bekliyor
G\xFCzergah       : ${senderDist} \u2794 ${receiverDist}
Yakla\u015F\u0131k Mesafe: ${approximateDistanceText}
Tahmini S\xFCre   : ${urgencyLabel}
\xDCcret          : ${price} TL
Kurye Hakedi\u015Fi : ${courierEarnings} TL
\xD6deme T\xFCr\xFC     : ${paymentMethodLabel}
Paket          : ${packageName}

--- G\xD6NDER\u0130C\u0130 B\u0130LG\u0130LER\u0130 ---
\u0130sim       : ${maskedSenderName}
Telefon    : ${maskedSenderPhone} (Talebi kabul edince a\xE7\u0131l\u0131r)
\u0130l\xE7e/Mah.  : ${senderDist}${senderNeighborhood}
A\xE7\u0131k Adres : ${maskedSenderAddr}

--- TESL\u0130MAT (ALICI) B\u0130LG\u0130LER\u0130 ---
\u0130sim       : ${maskedReceiverName}
Telefon    : ${maskedReceiverPhone} (Talebi kabul edince a\xE7\u0131l\u0131r)
\u0130l\xE7e/Mah.  : ${receiverDist}${receiverNeighborhood}
A\xE7\u0131k Adres : ${maskedReceiverAddr}

--- KURYE NOTU ---
${order.noteForCourier ? order.noteForCourier : "\xD6zel bir not belirtilmedi."}

Kurye Havuzu : https://www.antalyateslimat.com/#pakettalebi
Takip Sayfas\u0131: https://www.antalyateslimat.com/#tracker
========================================
${isTest ? "NOT: Bu e-posta yaln\u0131zca y\xF6netici kutusuna test olarak g\xF6nderilmi\u015Ftir. Kuryelere bildirim iletilmez." : ""}
`.trim();
  const htmlContent = `
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${subject}</title>
</head>
<body style="margin: 0; padding: 16px; background-color: #03140e; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #ffffff;">
  <div style="max-width: 600px; margin: 0 auto; background: #022017; border: 1px solid #059669; border-radius: 18px; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.5);">
    
    <!-- Header -->
    <div style="background: linear-gradient(135deg, #047857 0%, #065f46 100%); padding: 20px 24px; text-align: left;">
      <div style="display: flex; align-items: center; justify-content: space-between;">
        <span style="font-size: 11px; font-weight: 800; letter-spacing: 1px; text-transform: uppercase; background: rgba(0,0,0,0.25); color: #a7f3d0; padding: 4px 10px; border-radius: 8px;">
          ${isTest ? "\u{1F9EA} TEST / DO\u011ERULAMA" : "\u26A1 YEN\u0130 M\xDC\u015ETER\u0130 TALEB\u0130"}
        </span>
        <span style="color: #d1fae5; font-size: 12px;">${formattedDate}</span>
      </div>
      <h1 style="margin: 12px 0 4px 0; font-size: 24px; font-weight: 900; color: #ffffff;">
        Takip No: #${trackingCode}
      </h1>
      <p style="margin: 0; font-size: 14px; color: #ecfdf5; font-weight: 600;">
        ${senderDist} \u2794 ${receiverDist} | <span style="color: #6ee7b7; font-weight: 700;">\u{1F4CD} Yakla\u015F\u0131k: ${approximateDistanceText}</span> | <span style="color: #fde047; font-weight: 800;">${price} TL</span>
      </p>
    </div>

    <!-- Summary Badges -->
    <div style="padding: 16px 24px; background: #021a13; border-bottom: 1px solid rgba(16,185,129,0.2); display: flex; flex-wrap: wrap; gap: 8px;">
      <div style="background: rgba(16,185,129,0.15); border: 1px solid rgba(16,185,129,0.4); border-radius: 8px; padding: 8px 12px; margin: 4px;">
        <div style="font-size: 10px; color: #6ee7b7; font-weight: 700; text-transform: uppercase;">Yakla\u015F\u0131k Mesafe</div>
        <div style="font-size: 13px; color: #ffffff; font-weight: 700;">${approximateDistanceText}</div>
      </div>
      <div style="background: rgba(16,185,129,0.15); border: 1px solid rgba(16,185,129,0.4); border-radius: 8px; padding: 8px 12px; margin: 4px;">
        <div style="font-size: 10px; color: #6ee7b7; font-weight: 700; text-transform: uppercase;">\xD6deme T\xFCr\xFC</div>
        <div style="font-size: 13px; color: #ffffff; font-weight: 700;">${paymentMethodLabel}</div>
      </div>
      <div style="background: rgba(245,158,11,0.15); border: 1px solid rgba(245,158,11,0.4); border-radius: 8px; padding: 8px 12px; margin: 4px;">
        <div style="font-size: 10px; color: #fcd34d; font-weight: 700; text-transform: uppercase;">\xD6ncelik</div>
        <div style="font-size: 13px; color: #ffffff; font-weight: 700;">${urgencyLabel}</div>
      </div>
      <div style="background: rgba(59,130,246,0.15); border: 1px solid rgba(59,130,246,0.4); border-radius: 8px; padding: 8px 12px; margin: 4px;">
        <div style="font-size: 10px; color: #93c5fd; font-weight: 700; text-transform: uppercase;">Paket</div>
        <div style="font-size: 13px; color: #ffffff; font-weight: 700;">${packageName}</div>
      </div>
    </div>

    <!-- Details Body -->
    <div style="padding: 24px;">

      <!-- Sender Card -->
      <div style="background: #032d20; border: 1px solid rgba(16,185,129,0.3); border-radius: 12px; padding: 16px; margin-bottom: 16px;">
        <div style="color: #34d399; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px;">
          \u{1F4CD} ALINACAK YER (G\xD6NDER\u0130C\u0130)
        </div>
        <div style="font-size: 16px; font-weight: 800; color: #ffffff; margin-bottom: 4px;">
          ${maskedSenderName}
        </div>
        <div style="font-size: 13px; color: #6ee7b7; font-weight: 700; margin-bottom: 8px;">
          \u{1F4DE} ${maskedSenderPhone} <span style="font-size: 11px; color: #a7f3d0; font-weight: normal;">(Talebi kabul edince a\xE7\u0131l\u0131r)</span>
        </div>
        <div style="font-size: 13px; color: #a7f3d0; line-height: 1.4;">
          <strong style="color: #ffffff;">${senderDist}${senderNeighborhood}</strong><br>
          <span style="color: #6ee7b7;">${maskedSenderAddr}</span>
        </div>
      </div>

      <!-- Receiver Card -->
      <div style="background: #032d20; border: 1px solid rgba(16,185,129,0.3); border-radius: 12px; padding: 16px; margin-bottom: 16px;">
        <div style="color: #f59e0b; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px;">
          \u{1F3AF} TESL\u0130MAT YER\u0130 (ALICI)
        </div>
        <div style="font-size: 16px; font-weight: 800; color: #ffffff; margin-bottom: 4px;">
          ${maskedReceiverName}
        </div>
        <div style="font-size: 13px; color: #fcd34d; font-weight: 700; margin-bottom: 8px;">
          \u{1F4DE} ${maskedReceiverPhone} <span style="font-size: 11px; color: #fde68a; font-weight: normal;">(Talebi kabul edince a\xE7\u0131l\u0131r)</span>
        </div>
        <div style="font-size: 13px; color: #a7f3d0; line-height: 1.4;">
          <strong style="color: #ffffff;">${receiverDist}${receiverNeighborhood}</strong><br>
          <span style="color: #fcd34d;">${maskedReceiverAddr}</span>
        </div>
      </div>

      <!-- Customer Note -->
      ${order.noteForCourier ? `
      <div style="background: rgba(245,158,11,0.1); border: 1px dashed rgba(245,158,11,0.5); border-radius: 10px; padding: 12px; margin-bottom: 20px;">
        <div style="color: #fcd34d; font-size: 11px; font-weight: 800; margin-bottom: 4px;">\u{1F4AC} M\xDC\u015ETER\u0130 NOTU:</div>
        <div style="color: #ffffff; font-size: 13px; font-style: italic;">"${order.noteForCourier}"</div>
      </div>
      ` : ""}

      <!-- Action Button -->
      <div style="text-align: center; margin-top: 24px;">
        <a href="https://www.antalyateslimat.com/#pakettalebi" style="display: inline-block; background: #059669; color: #ffffff; font-weight: 800; font-size: 15px; padding: 14px 28px; border-radius: 12px; text-decoration: none; box-shadow: 0 4px 14px rgba(5,150,105,0.45);">
          \u{1F6F5} Kurye Havuzunda G\xF6r & Talebi Kabul Et
        </a>
      </div>

    </div>

    <!-- Footer -->
    <div style="background: #01150f; padding: 14px 24px; text-align: center; border-top: 1px solid rgba(16,185,129,0.2); font-size: 11px; color: #6ee7b7;">
      Antalya \u015Eehir \u0130\xE7i Moto Kurye & Teslimat A\u011F\u0131 7/24 \u2022 Bu e-posta sipari\u015F y\xF6netim bildirim sistemi taraf\u0131ndan otomatik olu\u015Fturulmu\u015Ftur.
    </div>

  </div>
</body>
</html>
`.trim();
  const job = {
    id: `job-${Date.now()}-${Math.floor(Math.random() * 1e3)}`,
    orderId,
    trackingCode,
    isTest,
    recipients,
    subject,
    textContent,
    htmlContent,
    status: "pending",
    attempts: 0,
    maxAttempts: 3,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  emailQueue.unshift(job);
  if (emailQueue.length > 200) {
    emailQueue.splice(200);
  }
  emailQueueEvents.emit("job_enqueued");
  return {
    success: true,
    jobId: job.id,
    status: "queued",
    recipients,
    message: "E-posta bildirim g\xF6revi asenkron kuyru\u011Fa al\u0131nd\u0131 ve an\u0131nda iletiliyor."
  };
}
async function syncUsersFromFirestoreSnapshot(snapshotDocs) {
  let updatedCount = 0;
  snapshotDocs.forEach((docSnap) => {
    const data = typeof docSnap.data === "function" ? docSnap.data() : docSnap;
    const docId = docSnap.id || data.id;
    if (!data || !docId) return;
    const u = { ...data, id: docId };
    const emailLower = (u.email || "").trim().toLowerCase();
    const existingIdx = dbState.users.findIndex(
      (x) => x.id === docId || emailLower && x.email && x.email.trim().toLowerCase() === emailLower
    );
    if (existingIdx >= 0) {
      dbState.users[existingIdx] = { ...dbState.users[existingIdx], ...u };
    } else {
      dbState.users.push(u);
      updatedCount++;
    }
    if (u.role === "courier") {
      const cIdx = dbState.couriers.findIndex(
        (c) => c.id === docId || emailLower && c.email && c.email.trim().toLowerCase() === emailLower
      );
      const courierInfo = {
        id: u.id,
        name: u.name,
        phone: u.phone,
        email: u.email,
        district: u.district || "Muratpa\u015Fa",
        rating: u.rating || 5,
        totalDeliveries: u.totalDeliveries || u.totalOrders || 0,
        currentLat: u.currentLat || 36.886,
        currentLng: u.currentLng || 30.7065,
        isOnline: u.isOnline !== false
      };
      if (cIdx >= 0) {
        dbState.couriers[cIdx] = { ...dbState.couriers[cIdx], ...courierInfo };
      } else {
        dbState.couriers.push(courierInfo);
      }
    }
  });
  if (updatedCount > 0) {
    saveDatabase();
  }
  console.log(`[FIRESTORE USERS SYNC] Synced Firestore users (${snapshotDocs.length} accounts). Active courier recipients: ${getRegisteredCourierEmails().join(", ")}`);
}
function initFirestoreSync() {
  if (!serverFirestoreDb) {
    console.warn("[FIRESTORE SYNC] Firestore DB not available on server, skipping real-time cloud sync.");
    return;
  }
  try {
    const usersColRef = (0, import_firestore.collection)(serverFirestoreDb, "users");
    (0, import_firestore.getDocs)(usersColRef).then((snap) => {
      if (snap && snap.docs.length > 0) {
        syncUsersFromFirestoreSnapshot(snap.docs);
      }
    }).catch((err) => console.warn("[FIRESTORE USERS GET ERR]", err.message));
    (0, import_firestore.onSnapshot)(
      usersColRef,
      (snapshot) => {
        syncUsersFromFirestoreSnapshot(snapshot.docs);
      },
      (err) => {
        console.warn("[FIRESTORE USERS LISTENER ERR]", err.message);
      }
    );
  } catch (err) {
    console.warn("[FIRESTORE USERS SYNC INIT FAIL]", err.message);
  }
  try {
    const colRef = (0, import_firestore.collection)(serverFirestoreDb, "delivery_requests");
    (0, import_firestore.onSnapshot)(
      colRef,
      (snapshot) => {
        let newOrUpdatedCount = 0;
        snapshot.docChanges().forEach((change) => {
          const data = change.doc.data();
          if (!data || !data.id || String(data.id).startsWith("req-sample-")) return;
          const docId = change.doc.id || data.id;
          const trackingCode = data.trackingCode || "ANT-0000";
          const fullOrder = { ...data, id: docId };
          const existingIdx = dbState.requests.findIndex(
            (r) => r.id === docId || r.trackingCode && r.trackingCode === trackingCode
          );
          if (existingIdx >= 0) {
            const currentReq = dbState.requests[existingIdx];
            dbState.requests[existingIdx] = { ...currentReq, ...fullOrder };
          } else {
            dbState.requests.unshift(fullOrder);
            newOrUpdatedCount++;
          }
          const isTest = isTestOrFakeOrder(fullOrder);
          const orderAgeRef = fullOrder.approvedAt || fullOrder.createdAt;
          const orderAgeMs = orderAgeRef ? Date.now() - new Date(orderAgeRef).getTime() : Infinity;
          const isFresh = orderAgeMs <= MAX_ORDER_EMAIL_AGE_MS;
          const isOrderEmailsActive = dbState.smtpConfig?.newOrderEmailsEnabled !== false;
          const isApprovedPool = fullOrder.status === "pending_pool";
          const needsEmail = isOrderEmailsActive && !isTest && isFresh && isApprovedPool && !fullOrder.emailDispatched && !dispatchedEmailOrderIds.has(docId) && !dispatchedEmailOrderIds.has(trackingCode);
          if (needsEmail) {
            console.log(`[FIRESTORE SYNC] \u{1F4E6} Approved pool order from Firestore detected: #${trackingCode} (${docId}). Triggering email queue...`);
            enqueueNewOrderEmail(fullOrder, void 0, false);
          } else if (!isFresh && isApprovedPool) {
            dispatchedEmailOrderIds.add(docId);
            dispatchedEmailOrderIds.add(trackingCode);
          }
        });
        saveDatabase();
        if (newOrUpdatedCount > 0) {
          console.log(`[FIRESTORE SYNC] Real-time synced ${newOrUpdatedCount} new orders from Cloud Firestore.`);
        }
      },
      (err) => {
        console.warn("[FIRESTORE SYNC ERROR]", err.message);
      }
    );
  } catch (err) {
    console.warn("[FIRESTORE SYNC INIT FAIL]", err.message);
  }
  try {
    const counterDocRef = (0, import_firestore.doc)(serverFirestoreDb, "settings", "site_counter");
    (0, import_firestore.onSnapshot)(
      counterDocRef,
      (docSnap) => {
        if (docSnap.exists()) {
          const cloudData = docSnap.data();
          if (cloudData && typeof cloudData.totalVisits === "number") {
            if (!dbState.visitorStats) {
              dbState.visitorStats = { ...DEFAULT_VISITOR_STATS };
            }
            const cloudTotal = Number(cloudData.totalVisits) || 0;
            const currentTotal = dbState.visitorStats.totalVisits || 0;
            if (cloudTotal > currentTotal) {
              dbState.visitorStats.totalVisits = cloudTotal;
              dbState.visitorStats.uniqueVisitors = Math.max(dbState.visitorStats.uniqueVisitors || 0, Number(cloudData.uniqueVisitors) || 0);
              if (cloudData.todayVisits && (!dbState.visitorStats.todayVisits || Number(cloudData.todayVisits) > dbState.visitorStats.todayVisits)) {
                dbState.visitorStats.todayVisits = Number(cloudData.todayVisits);
              }
              if (cloudData.lastVisitAt) {
                dbState.visitorStats.lastVisitAt = cloudData.lastVisitAt;
              }
              saveDatabase();
              console.log(`[FIRESTORE COUNTER SYNC] Site counter synced with Cloud Firestore: Total=${cloudTotal}`);
            }
          }
        }
      },
      (err) => {
        console.warn("[FIRESTORE COUNTER SYNC ERROR]", err.message);
      }
    );
  } catch (err) {
    console.warn("[FIRESTORE COUNTER SYNC INIT FAIL]", err.message);
  }
  try {
    const pwdReqColRef = (0, import_firestore.collection)(serverFirestoreDb, "password_reset_requests");
    (0, import_firestore.onSnapshot)(
      pwdReqColRef,
      (snapshot) => {
        snapshot.docChanges().forEach(async (change) => {
          if (change.type === "added" || change.type === "modified") {
            const data = change.doc.data();
            if (data && data.status === "pending") {
              console.log(`[FIRESTORE PWD RESET] \u{1F511} New password reset request detected: ${data.emailOrIdentifier} (${change.doc.id})`);
              const docRef = (0, import_firestore.doc)(serverFirestoreDb, "password_reset_requests", change.doc.id);
              try {
                await (0, import_firestore.setDoc)(docRef, { status: "processing" }, { merge: true });
                const result = await processPasswordResetRequest({
                  emailOrIdentifier: data.emailOrIdentifier,
                  role: data.role,
                  userHint: data.userHint
                });
                await (0, import_firestore.setDoc)(docRef, {
                  status: result.success ? "completed" : "failed",
                  error: result.error || null,
                  message: result.message || null,
                  email: result.email || null,
                  refCode: result.refCode || null,
                  isSelfSent: result.isSelfSent || false,
                  processedAt: (/* @__PURE__ */ new Date()).toISOString()
                }, { merge: true });
                console.log(`[FIRESTORE PWD RESET] Request ${change.doc.id} processed: ${result.success ? "SUCCESS" : "FAILED - " + result.error}`);
              } catch (procErr) {
                console.error("[FIRESTORE PWD RESET PROC ERROR]", procErr);
                await (0, import_firestore.setDoc)(docRef, {
                  status: "failed",
                  error: procErr?.message || "\u0130\u015Flem s\u0131ras\u0131nda hata meydana geldi.",
                  processedAt: (/* @__PURE__ */ new Date()).toISOString()
                }, { merge: true });
              }
            }
          }
        });
      },
      (err) => {
        console.warn("[FIRESTORE PWD RESET LISTENER ERROR]", err.message);
      }
    );
  } catch (err) {
    console.warn("[FIRESTORE PWD RESET INIT FAIL]", err.message);
  }
}
initFirestoreSync();
setInterval(() => {
  if (Array.isArray(dbState.requests)) {
    const now = Date.now();
    dbState.requests.forEach((r) => {
      if (!r || !r.id || isTestOrFakeOrder(r)) return;
      const orderAgeMs = r.createdAt ? now - new Date(r.createdAt).getTime() : Infinity;
      if (orderAgeMs > MAX_ORDER_EMAIL_AGE_MS) {
        if (!r.emailDispatched) {
          r.emailDispatched = true;
          r.emailDispatchedAt = r.emailDispatchedAt || "stale_skipped";
          if (r.id) dispatchedEmailOrderIds.add(r.id);
          if (r.trackingCode) dispatchedEmailOrderIds.add(r.trackingCode);
        }
        return;
      }
      const isOrderEmailsActive = dbState.smtpConfig?.newOrderEmailsEnabled === true;
      if (!isOrderEmailsActive) return;
      const isApprovedPool = r.status === "pending_pool";
      const isUnsent = isApprovedPool && !r.emailDispatched && !dispatchedEmailOrderIds.has(r.id) && (!r.trackingCode || !dispatchedEmailOrderIds.has(r.trackingCode));
      if (isUnsent) {
        console.log(`[AUTO SWEEP] \u{1F680} Auto-dispatching approved pool order #${r.trackingCode} (${r.id})...`);
        enqueueNewOrderEmail(r, void 0, false);
      }
    });
  }
}, 1e4);
app.get("/robots.txt", (req, res) => {
  res.type("text/plain");
  res.send(`# robots.txt for Antalya Teslimat 7/24
User-agent: *
Allow: /
Disallow: /api/

User-agent: Googlebot
Allow: /

Sitemap: https://www.antalyateslimat.com/sitemap.xml
`);
});
app.get("/sitemap.xml", (req, res) => {
  res.type("application/xml");
  res.send(`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
  <url>
    <loc>https://www.antalyateslimat.com/</loc>
    <lastmod>${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
    <image:image>
      <image:loc>https://www.antalyateslimat.com/app-logo.png</image:loc>
      <image:title>Antalya Paket G\xF6nder &amp; Kurye \xC7a\u011F\u0131r</image:title>
      <image:caption>Antalya 7/24 \u015Eehir \u0130\xE7i Acil Moto Kurye ve Paket G\xF6nderim Servisi</image:caption>
    </image:image>
  </url>
</urlset>`);
});
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: (/* @__PURE__ */ new Date()).toISOString(), requestsCount: dbState.requests.length });
});
app.get("/api/sync", (req, res) => {
  const tenMinutesAgo = Date.now() - 10 * 60 * 1e3;
  const recentList = dbState.visitorStats?.recentVisitors || [];
  const activeNow = recentList.filter((v) => new Date(v.timestamp).getTime() >= tenMinutesAgo).length;
  res.json({
    success: true,
    requests: dbState.requests,
    users: dbState.users,
    couriers: dbState.couriers,
    visitorStats: dbState.visitorStats ? {
      totalVisits: dbState.visitorStats.totalVisits || 0,
      uniqueVisitors: dbState.visitorStats.uniqueVisitors || 0,
      todayVisits: dbState.visitorStats.todayVisits || 0,
      todayDate: dbState.visitorStats.todayDate,
      lastVisitAt: dbState.visitorStats.lastVisitAt,
      activeNow: Math.max(1, activeNow),
      recentVisitors: recentList.slice(0, 30)
    } : void 0,
    updatedAt: dbState.updatedAt
  });
});
app.get("/api/email-queue", (req, res) => {
  const pendingCount = emailQueue.filter((j) => j.status === "pending").length;
  const processingCount = emailQueue.filter((j) => j.status === "processing").length;
  const sentCount = emailQueue.filter((j) => j.status === "sent").length;
  const failedCount = emailQueue.filter((j) => j.status === "failed").length;
  res.json({
    success: true,
    queueSummary: {
      total: emailQueue.length,
      pending: pendingCount,
      processing: processingCount,
      sent: sentCount,
      failed: failedCount,
      isWorkerActive: isQueueWorkerRunning
    },
    recentJobs: emailQueue.slice(0, 30)
  });
});
app.get("/api/requests", (req, res) => {
  res.json(dbState.requests || []);
});
var geocodeCache = /* @__PURE__ */ new Map();
var routeDistanceCache = /* @__PURE__ */ new Map();
var ANTALYA_DISTRICT_CENTERS = {
  "Muratpa\u015Fa": { lat: 36.886, lng: 30.7065 },
  "Konyaalt\u0131": { lat: 36.8732, lng: 30.6384 },
  "Kepez": { lat: 36.925, lng: 30.687 },
  "Lara (Muratpa\u015Fa)": { lat: 36.852, lng: 30.765 },
  "Lara": { lat: 36.852, lng: 30.765 }
};
function calculateHaversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}
async function resolveAntalyaCoords(address, district, fallbackCoords) {
  if (fallbackCoords && typeof fallbackCoords.lat === "number" && typeof fallbackCoords.lng === "number" && fallbackCoords.lat > 35 && fallbackCoords.lat < 38) {
    return { lat: fallbackCoords.lat, lng: fallbackCoords.lng };
  }
  const cleanAddr = (address || "").trim();
  const cleanDist = (district || "").trim();
  const cacheKey = `${cleanAddr.toLowerCase()}_${cleanDist.toLowerCase()}`;
  if (geocodeCache.has(cacheKey)) {
    return geocodeCache.get(cacheKey);
  }
  const queries = [];
  if (cleanAddr) {
    queries.push(`${cleanAddr}, ${cleanDist}, Antalya`);
    const firstWord = cleanAddr.split(/[,;\s]/)[0];
    if (firstWord && firstWord.length > 3) {
      queries.push(`${firstWord}, ${cleanDist}, Antalya`);
    }
  }
  if (cleanDist) {
    queries.push(`${cleanDist}, Antalya`);
  }
  for (const q of queries) {
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(q)}&countrycodes=tr&limit=1`,
        {
          headers: { "User-Agent": "AntalyaKuryeTeslimat/1.0 (kuryeantalyam@gmail.com)" },
          signal: AbortSignal.timeout(3e3)
        }
      );
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0 && data[0].lat && data[0].lon) {
          const pos = { lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) };
          geocodeCache.set(cacheKey, pos);
          return pos;
        }
      }
    } catch {
    }
  }
  const center = ANTALYA_DISTRICT_CENTERS[cleanDist] || ANTALYA_DISTRICT_CENTERS["Muratpa\u015Fa"];
  geocodeCache.set(cacheKey, center);
  return center;
}
app.post("/api/distance/measure", async (req, res) => {
  try {
    const { pickupAddress, pickupDistrict, destAddress, destDistrict, pickupCoords, destCoords } = req.body;
    const p1 = await resolveAntalyaCoords(pickupAddress, pickupDistrict, pickupCoords);
    const p2 = await resolveAntalyaCoords(destAddress, destDistrict, destCoords);
    const cacheKey = `${p1.lat.toFixed(4)},${p1.lng.toFixed(4)}_${p2.lat.toFixed(4)},${p2.lng.toFixed(4)}`;
    if (routeDistanceCache.has(cacheKey)) {
      const cached = routeDistanceCache.get(cacheKey);
      res.json({ success: true, ...cached, pickupCoords: p1, destCoords: p2, source: "cached" });
      return;
    }
    let distanceKm = 0;
    let durationMins = 0;
    let source = "osrm";
    try {
      const osrmRes = await fetch(
        `https://router.project-osrm.org/route/v1/driving/${p1.lng},${p1.lat};${p2.lng},${p2.lat}?overview=false`,
        { signal: AbortSignal.timeout(3e3) }
      );
      if (osrmRes.ok) {
        const data = await osrmRes.json();
        if (data?.routes?.[0]?.distance) {
          const meters = Number(data.routes[0].distance);
          const seconds = Number(data.routes[0].duration);
          distanceKm = Math.round(meters / 1e3 * 10) / 10;
          durationMins = Math.max(15, Math.round(seconds / 60));
        }
      }
    } catch {
    }
    if (!distanceKm || distanceKm <= 0) {
      source = "haversine_road_grid";
      const straight = calculateHaversineKm(p1.lat, p1.lng, p2.lat, p2.lng);
      distanceKm = Math.max(2, Math.round(straight * 1.32 * 10) / 10);
      durationMins = Math.max(15, Math.round(9 + distanceKm * 1.5));
    }
    const payload = { distanceKm, durationMins, pickupCoords: p1, destCoords: p2 };
    routeDistanceCache.set(cacheKey, { distanceKm, durationMins });
    res.json({ success: true, ...payload, source });
  } catch (err) {
    res.status(500).json({ error: "Mesafe hesaplanamad\u0131", message: err?.message });
  }
});
app.post("/api/requests", (req, res) => {
  try {
    const newRequest = req.body;
    if (!newRequest || !newRequest.id || !newRequest.sender || !newRequest.receiver) {
      res.status(400).json({ error: "Ge\xE7ersiz talep parametreleri" });
      return;
    }
    if (!newRequest.status) {
      newRequest.status = "pending_admin";
    }
    if (!newRequest.createdAt) {
      newRequest.createdAt = (/* @__PURE__ */ new Date()).toISOString();
    }
    newRequest.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    const existingIndex = dbState.requests.findIndex(
      (r) => r.id === newRequest.id || r.trackingCode && r.trackingCode === newRequest.trackingCode
    );
    let isAlreadyDispatched = false;
    if (existingIndex >= 0) {
      const existingReq = dbState.requests[existingIndex];
      isAlreadyDispatched = Boolean(existingReq.emailDispatched);
      newRequest.emailDispatched = existingReq.emailDispatched;
      newRequest.emailDispatchedAt = existingReq.emailDispatchedAt;
      dbState.requests[existingIndex] = { ...existingReq, ...newRequest };
    } else {
      dbState.requests.unshift(newRequest);
    }
    if (newRequest.senderUserId) {
      const user = dbState.users.find((u) => u.id === newRequest.senderUserId);
      if (user) {
        user.totalOrders = (user.totalOrders || 0) + 1;
      }
    }
    saveDatabase();
    console.log(`[ORDER SAVED] ID: ${newRequest.id}, Tracking: ${newRequest.trackingCode}, Status: ${newRequest.status}, Price: ${newRequest.price} TL`);
    if (serverFirestoreDb && newRequest.id) {
      (0, import_firestore.setDoc)((0, import_firestore.doc)(serverFirestoreDb, "delivery_requests", newRequest.id), JSON.parse(JSON.stringify(newRequest)), { merge: true }).catch((e) => console.warn("[SERVER FIRESTORE SAVE WARN]", e?.message));
    }
    let queueResult = { status: "pending_admin_approval" };
    if (newRequest.status === "pending_pool") {
      queueResult = enqueueNewOrderEmail(newRequest, void 0, isAlreadyDispatched ? false : false);
    }
    res.json({
      success: true,
      request: newRequest,
      queueResult,
      emailResult: {
        success: true,
        status: queueResult.status || "queued",
        isRealDelivery: true,
        message: newRequest.status === "pending_admin" ? "Sipari\u015F y\xF6netici onay\u0131na iletildi. Onayland\u0131ktan sonra kurye havuzuna d\xFC\u015Fecektir." : "Sipari\u015F kurye havuzuna iletildi."
      }
    });
  } catch (err) {
    console.error("Error creating request:", err);
    res.status(500).json({ error: err.message || "Sunucu hatas\u0131" });
  }
});
app.post("/api/requests/:id/resend-email", (req, res) => {
  try {
    const { id } = req.params;
    const targetEmail = req.body?.targetEmail;
    const order = dbState.requests.find((r) => r.id === id || r.trackingCode === id);
    if (!order) {
      res.status(404).json({ error: "Sipari\u015F bulunamad\u0131." });
      return;
    }
    const queueResult = enqueueNewOrderEmail(order, targetEmail, true);
    res.json({
      success: true,
      orderId: order.id,
      trackingCode: order.trackingCode,
      queueResult,
      emailResult: {
        success: true,
        status: "queued",
        isRealDelivery: true
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.all(["/api/requests/force-dispatch/:idOrCode", "/api/requests/:idOrCode/force-dispatch"], (req, res) => {
  try {
    const { idOrCode } = req.params;
    const targetEmail = req.body?.targetEmail || req.query.targetEmail;
    const order = dbState.requests.find(
      (r) => r.id === idOrCode || r.trackingCode === idOrCode || r.trackingCode && r.trackingCode.replace(/\D/g, "") === idOrCode.replace(/\D/g, "")
    );
    if (!order) {
      res.status(404).json({ error: `Sipari\u015F bulunamad\u0131: ${idOrCode}` });
      return;
    }
    const queueResult = enqueueNewOrderEmail(order, typeof targetEmail === "string" ? targetEmail : void 0, true);
    res.json({
      success: true,
      order,
      queueResult,
      message: `${order.trackingCode} i\xE7in e-posta bildirimi an\u0131nda s\u0131raya al\u0131nd\u0131 ve iletiliyor.`
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.post("/api/requests/sync-batch", (req, res) => {
  try {
    const { requests } = req.body || {};
    if (!Array.isArray(requests)) {
      res.status(400).json({ error: "Ge\xE7ersiz istek dizisi" });
      return;
    }
    let enqueuedCount = 0;
    const now = Date.now();
    requests.forEach((reqItem) => {
      if (!reqItem || !reqItem.id || isTestOrFakeOrder(reqItem)) return;
      const orderAgeMs = reqItem.createdAt ? now - new Date(reqItem.createdAt).getTime() : Infinity;
      const isFresh = orderAgeMs <= MAX_ORDER_EMAIL_AGE_MS;
      const idx = dbState.requests.findIndex(
        (r) => r.id === reqItem.id || r.trackingCode && r.trackingCode === reqItem.trackingCode
      );
      if (idx >= 0) {
        const existing = dbState.requests[idx];
        dbState.requests[idx] = { ...existing, ...reqItem };
        if (isFresh && reqItem.status === "pending_pool" && !existing.emailDispatched && !reqItem.emailDispatched) {
          enqueueNewOrderEmail(dbState.requests[idx], void 0, false);
          enqueuedCount++;
        }
      } else {
        dbState.requests.unshift(reqItem);
        if (isFresh && reqItem.status === "pending_pool" && !reqItem.emailDispatched) {
          enqueueNewOrderEmail(reqItem, void 0, false);
          enqueuedCount++;
        }
      }
    });
    saveDatabase();
    res.json({ success: true, count: requests.length, enqueuedCount });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.post("/api/auth/login", (req, res) => {
  try {
    const { identifier, password, expectedRole } = req.body || {};
    if (!identifier) {
      res.status(400).json({ error: "Kullan\u0131c\u0131 ad\u0131, e-posta veya telefon giriniz." });
      return;
    }
    const rawClean = identifier.trim().toLowerCase();
    const normalize = (str) => (str || "").toLowerCase().trim().replace(/ğ/g, "g").replace(/ü/g, "u").replace(/ş/g, "s").replace(/ı/g, "i").replace(/ö/g, "o").replace(/ç/g, "c");
    const clean = normalize(rawClean);
    const digitsOnly = rawClean.replace(/\D/g, "");
    let found = dbState.users.find(
      (u) => u.email && (u.email.toLowerCase() === rawClean || normalize(u.email) === clean) || u.name && (normalize(u.name) === clean || normalize(u.name).includes(clean)) || digitsOnly.length >= 7 && (u.phone || "").replace(/\D/g, "").endsWith(digitsOnly)
    );
    if (!found) {
      res.status(404).json({ error: "Bu bilgilere ait kay\u0131tl\u0131 kullan\u0131c\u0131 bulunamad\u0131." });
      return;
    }
    if (expectedRole) {
      if (expectedRole === "courier" && found.role === "customer") {
        res.status(403).json({ error: "Bu hesap M\xFC\u015Fteri hesab\u0131d\u0131r. Kurye paneline giri\u015F yapamazs\u0131n\u0131z. L\xFCtfen M\xFC\u015Fteri Giri\u015Fi ekran\u0131n\u0131 kullan\u0131n\u0131z." });
        return;
      }
      if (expectedRole === "customer" && found.role === "courier") {
        res.status(403).json({ error: "Bu hesap Kurye hesab\u0131d\u0131r. M\xFC\u015Fteri paneline giri\u015F yapamazs\u0131n\u0131z. L\xFCtfen Kurye Giri\u015Fi ekran\u0131n\u0131 kullan\u0131n\u0131z." });
        return;
      }
      if (expectedRole === "admin" && found.role !== "admin") {
        res.status(403).json({ error: "Bu hesap Y\xF6netici yetkisine sahip de\u011Fildir." });
        return;
      }
    }
    if (!password || password.trim() === "") {
      res.status(400).json({ error: "L\xFCtfen \u015Fifrenizi giriniz." });
      return;
    }
    const userExpected = (found.password || "").trim();
    const entered = password.trim();
    if (entered !== userExpected) {
      res.status(401).json({ error: "Girdi\u011Finiz \u015Fifre hatal\u0131d\u0131r! L\xFCtfen kay\u0131t olurken belirledi\u011Finiz \u015Fifreyi giriniz." });
      return;
    }
    res.json({ success: true, user: found });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.get("/api/email-logs", (req, res) => {
  res.json({
    success: true,
    emailLogs: dbState.emailLogs || [],
    courierRecipients: getRegisteredCourierEmails()
  });
});
app.get("/api/smtp-config", (req, res) => {
  const cfg = dbState.smtpConfig || {};
  const hasPass = Boolean(cfg.pass || process.env.SMTP_PASS || process.env.GMAIL_APP_PASSWORD);
  const user = cfg.user || process.env.SMTP_USER || process.env.GMAIL_USER || "kuryeantalyam@gmail.com";
  res.json({
    success: true,
    config: {
      service: cfg.service || (user.toLowerCase().endsWith("@gmail.com") ? "gmail" : "custom"),
      host: cfg.host || "smtp.gmail.com",
      port: Number(cfg.port) || 587,
      secure: Boolean(cfg.secure),
      user,
      fromName: cfg.fromName || "Antalya \u015Eehir \u0130\xE7i Teslimat 7/24",
      fromEmail: cfg.fromEmail || user || "kuryeantalyam@gmail.com",
      enabled: cfg.enabled !== false,
      newOrderEmailsEnabled: Boolean(cfg.newOrderEmailsEnabled),
      hasPassword: hasPass,
      lastTestedAt: cfg.lastTestedAt,
      lastTestStatus: cfg.lastTestStatus,
      lastTestMessage: cfg.lastTestMessage
    },
    isConfigured: hasPass && Boolean(user)
  });
});
app.post("/api/notifications/toggle-order-emails", (req, res) => {
  try {
    const { enabled } = req.body || {};
    if (!dbState.smtpConfig) {
      dbState.smtpConfig = { ...DEFAULT_SMTP_CONFIG };
    }
    const currentStatus = dbState.smtpConfig.newOrderEmailsEnabled === true;
    const newStatus = typeof enabled === "boolean" ? enabled : !currentStatus;
    dbState.smtpConfig.newOrderEmailsEnabled = newStatus;
    saveDatabase();
    console.log(`[ORDER EMAILS TOGGLED] Yeni talep mailleri durumu: ${newStatus ? "A\xC7IK" : "KAPALI"}`);
    res.json({
      success: true,
      newOrderEmailsEnabled: newStatus,
      message: newStatus ? "Yeni sipari\u015F e-posta bildirimleri a\xE7\u0131ld\u0131." : "Yeni sipari\u015F e-posta bildirimleri kapat\u0131ld\u0131 (kimseye mail gitmeyecek)."
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.post("/api/smtp-config", async (req, res) => {
  try {
    const { service, host, port, secure, user, pass, fromName, fromEmail, enabled, newOrderEmailsEnabled } = req.body;
    const existing = dbState.smtpConfig || {};
    const finalPass = pass && pass.trim() !== "" ? pass.trim() : existing.pass || process.env.SMTP_PASS || process.env.GMAIL_APP_PASSWORD || "";
    const cleanUser = (user || existing.user || "kuryeantalyam@gmail.com").trim();
    const newConfig = {
      service: service || (cleanUser.toLowerCase().endsWith("@gmail.com") ? "gmail" : "custom"),
      host: host || "smtp.gmail.com",
      port: Number(port) || 587,
      secure: Boolean(secure),
      user: cleanUser,
      pass: finalPass,
      fromName: (fromName || "Antalya \u015Eehir \u0130\xE7i Teslimat 7/24").trim(),
      fromEmail: (fromEmail || cleanUser || "kuryeantalyam@gmail.com").trim(),
      enabled: enabled !== false,
      newOrderEmailsEnabled: typeof newOrderEmailsEnabled === "boolean" ? newOrderEmailsEnabled : Boolean(existing.newOrderEmailsEnabled)
    };
    let testVerified = false;
    let testMessage = "";
    if (newConfig.user && newConfig.pass && newConfig.enabled) {
      try {
        let testTransporter;
        if (newConfig.service === "gmail" || newConfig.user.toLowerCase().endsWith("@gmail.com")) {
          testTransporter = import_nodemailer.default.createTransport({
            service: "gmail",
            auth: { user: newConfig.user, pass: newConfig.pass }
          });
        } else {
          testTransporter = import_nodemailer.default.createTransport({
            host: newConfig.host,
            port: newConfig.port,
            secure: newConfig.secure,
            auth: { user: newConfig.user, pass: newConfig.pass },
            tls: { rejectUnauthorized: false }
          });
        }
        await testTransporter.verify();
        testVerified = true;
        testMessage = "SMTP sunucu ba\u011Flant\u0131s\u0131 ve kimlik do\u011Frulama ba\u015Far\u0131yla onayland\u0131. E-postalar art\u0131k ger\xE7ek kutulara g\xF6nderilecek.";
        newConfig.lastTestStatus = "success";
        newConfig.lastTestMessage = testMessage;
      } catch (verifyErr) {
        testVerified = false;
        let errMsg = verifyErr.message || "Bilinmeyen hata";
        if (errMsg.includes("535") || errMsg.includes("BadCredentials") || errMsg.includes("Username and Password not accepted") || errMsg.includes("Invalid login")) {
          errMsg = 'E-posta veya \u015Fifre hatal\u0131! Gmail i\xE7in normal \u015Fifre yerine Google Hesab\u0131n\u0131zdan olu\u015Fturaca\u011F\u0131n\u0131z 16 haneli "Uygulama \u015Eifresi" (App Password) gereklidir.';
        }
        testMessage = `Ba\u011Flant\u0131 hatas\u0131: ${errMsg}`;
        newConfig.lastTestStatus = "error";
        newConfig.lastTestMessage = testMessage;
      }
    } else {
      testMessage = "\u015Eifre girilmedi; yap\u0131land\u0131rma kaydedildi.";
    }
    newConfig.lastTestedAt = (/* @__PURE__ */ new Date()).toISOString();
    dbState.smtpConfig = newConfig;
    saveDatabase();
    res.json({
      success: true,
      verified: testVerified,
      message: testMessage,
      config: {
        ...newConfig,
        pass: void 0,
        hasPassword: Boolean(newConfig.pass)
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message || "Sunucu hatas\u0131" });
  }
});
app.post("/api/notifications/test-email", async (req, res) => {
  try {
    const { targetEmail } = req.body || {};
    let effectiveTarget = "kuryeantalyam@gmail.com";
    if (targetEmail && targetEmail !== "all" && targetEmail.includes("@")) {
      const cleanTarget = targetEmail.trim().toLowerCase();
      const isRegisteredCourier = (dbState.users || []).some(
        (u) => u.role === "courier" && u.email && u.email.toLowerCase() === cleanTarget && cleanTarget !== "kuryeantalyam@gmail.com"
      );
      if (isRegisteredCourier) {
        console.warn(`[SAFETY] Prevented test email to courier ${cleanTarget}. Redirecting to admin email.`);
        effectiveTarget = "kuryeantalyam@gmail.com";
      } else {
        effectiveTarget = cleanTarget;
      }
    }
    const sampleOrder = {
      id: `req-test-${Date.now()}`,
      trackingCode: `ANT-TEST`,
      isTest: true,
      packageName: "\xD6rnek Test Paketi (Sistem Do\u011Frulama)",
      price: 250,
      courierEarnings: 215,
      paymentMethod: "alici_odemeli",
      sender: {
        district: "Muratpa\u015Fa",
        neighborhood: "\u015Eirinyal\u0131",
        addressDetail: "\u0130smet G\xF6k\u015Fen Cad. No:45/B",
        contactName: "Antalya Test G\xF6nderici",
        contactPhone: "0532 000 11 22"
      },
      receiver: {
        district: "Konyaalt\u0131",
        neighborhood: "G\xFCrsu",
        addressDetail: "G\xFCrsu Mah. 304. Sok. No:12",
        contactName: "Antalya Test Al\u0131c\u0131",
        contactPhone: "0544 333 44 55"
      },
      noteForCourier: "Bu bir sistem kontrol ve do\u011Frulama e-postas\u0131d\u0131r. Kuryelere bildirim iletilmez."
    };
    const result = enqueueNewOrderEmail(sampleOrder, effectiveTarget, true);
    res.json({ success: true, result, target: effectiveTarget });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.post("/api/notifications/send-apk-promo-email", async (req, res) => {
  try {
    const { targetEmail } = req.body || {};
    const recipient = (targetEmail || "cantalyacanta@gmail.com").trim().toLowerCase();
    if (!recipient || !recipient.includes("@")) {
      return res.status(400).json({ error: "Ge\xE7ersiz e-posta adresi." });
    }
    const mailDetails = getMailTransporter();
    const transporter = mailDetails.transporter;
    const fromAddress = mailDetails.fromAddress;
    const apkUrl = "https://www.antalyateslimat.com/downloads/Antalya-Kurye-Talep-Havuzu.apk";
    const webUrl = "https://www.antalyateslimat.com/";
    const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Antalya Kurye Mobil Uygulamas\u0131</title>
    </head>
    <body style="margin: 0; padding: 20px 10px; background-color: #0f172a; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc;">
      <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px; margin: 0 auto; background-color: #022019; border-radius: 16px; overflow: hidden; border: 1px solid #059669; box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5);">
        <tr>
          <td style="background: linear-gradient(135deg, #047857 0%, #0d9488 100%); padding: 32px 24px; text-align: center;">
            <div style="display: inline-block; width: 64px; height: 64px; background-color: rgba(255, 255, 255, 0.15); border-radius: 18px; margin-bottom: 12px; line-height: 64px; text-align: center;">
              <span style="font-size: 36px;">\u{1F6B4}</span>
            </div>
            <h1 style="margin: 0; font-size: 24px; font-weight: 800; color: #ffffff; letter-spacing: 0.5px;">Antalya Kurye Ekspres</h1>
            <p style="margin: 8px 0 0 0; font-size: 15px; color: #a7f3d0; font-weight: 500;">Kuryeler \u0130\xE7in \xD6zel Android Mobil Uygulamas\u0131 (APK)</p>
          </td>
        </tr>
        <tr>
          <td style="padding: 32px 24px; color: #e2e8f0;">
            <p style="font-size: 16px; margin-top: 0; color: #ffffff; font-weight: 700;">Merhaba Say\u0131n Kuryemiz (${recipient}),</p>
            <p style="font-size: 14px; line-height: 1.7; color: #cbd5e1; margin-bottom: 24px;">
              Antalya genelindeki paket ve teslimat taleplerini an\u0131nda yakalaman\u0131z i\xE7in geli\u015Ftirilen <strong>Antalya Kurye Android Mobil Uygulamas\u0131 (v1.5.0)</strong> kullan\u0131ma sunuldu!
            </p>
            
            <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom: 24px;">
              <tr>
                <td style="padding: 12px; background-color: #032d24; border: 1px solid #065f46; border-radius: 12px; margin-bottom: 10px;">
                  <strong style="color: #34d399; font-size: 14px;">\u{1F514} Ekran Kapal\u0131yken Sesli & Titre\u015Fimli \xC7a\u011Fr\u0131</strong>
                  <p style="margin: 4px 0 0 0; font-size: 13px; color: #94a3b8; line-height: 1.5;">
                    Telefonunuz cebinizdeyken veya ekran\u0131 kilitliyken yeni paket d\xFC\u015Ft\xFC\u011F\xFCnde y\xFCksek sesli siren ve titre\u015Fim ile an\u0131nda uyar\u0131r.
                  </p>
                </td>
              </tr>
              <tr><td style="height: 10px;"></td></tr>
              <tr>
                <td style="padding: 12px; background-color: #032d24; border: 1px solid #065f46; border-radius: 12px; margin-bottom: 10px;">
                  <strong style="color: #34d399; font-size: 14px;">\u26A1 \xDCst Bildirim \xC7ubu\u011Fu Canl\u0131 Durumu</strong>
                  <p style="margin: 4px 0 0 0; font-size: 13px; color: #94a3b8; line-height: 1.5;">
                    Bildirim \xE7ubu\u011Funda s\xFCrekli canl\u0131 kalarak arka planda kapanmaz, paket ka\xE7\u0131rman\u0131z\u0131 engeller.
                  </p>
                </td>
              </tr>
              <tr><td style="height: 10px;"></td></tr>
              <tr>
                <td style="padding: 12px; background-color: #032d24; border: 1px solid #065f46; border-radius: 12px;">
                  <strong style="color: #34d399; font-size: 14px;">\u{1F6B4} Yenilenen Ye\u015Fil Bisiklet \u0130konu</strong>
                  <p style="margin: 4px 0 0 0; font-size: 13px; color: #94a3b8; line-height: 1.5;">
                    Telefonunuzun ana ekran\u0131nda kolayca fark edebilece\u011Finiz z\xFCmr\xFCt ye\u015Fili zemin \xFCzerine beyaz bisiklet ikonu uyguland\u0131.
                  </p>
                </td>
              </tr>
            </table>
            
            <!-- Main CTA Button -->
            <table align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 28px auto 24px auto;">
              <tr>
                <td align="center" style="border-radius: 14px; background: linear-gradient(135deg, #10b981 0%, #059669 100%); box-shadow: 0 4px 15px rgba(16, 185, 129, 0.4);">
                  <a href="${apkUrl}" target="_blank" style="display: inline-block; padding: 16px 36px; font-size: 15px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: 0.3px;">
                    \u{1F4F2} Antalya Kurye APK'y\u0131 \u0130ndir (v1.5.0)
                  </a>
                </td>
              </tr>
            </table>
            
            <div style="background-color: #061e18; border: 1px solid #0f4c3a; border-radius: 12px; padding: 18px; margin-top: 24px;">
              <h4 style="margin: 0 0 10px 0; font-size: 13px; color: #6ee7b7; text-transform: uppercase; letter-spacing: 0.5px;">\u{1F4CC} Kurulum Talimatlar\u0131:</h4>
              <ol style="margin: 0; padding-left: 20px; font-size: 13px; color: #cbd5e1; line-height: 1.7;">
                <li>Yukar\u0131daki <strong>"APK'y\u0131 \u0130ndir"</strong> butonuna t\u0131klayarak dosyay\u0131 telefonunuza kaydedin.</li>
                <li>\u0130ndirme tamamland\u0131\u011F\u0131nda bildirime t\u0131klay\u0131p kurulumu ba\u015Flat\u0131n. <em>("Bilinmeyen kaynaklar" uyar\u0131s\u0131 \xE7\u0131karsa izin veriniz)</em>.</li>
                <li><strong>\xD6nemli:</strong> Telefonunuzda uygulaman\u0131n daha \xF6nceki bir s\xFCr\xFCm\xFC y\xFCkl\xFCyse, imza uyu\u015Fmazl\u0131\u011F\u0131 ya\u015Famamak i\xE7in l\xFCtfen \xF6nce eski uygulamay\u0131 kald\u0131r\u0131p ard\u0131ndan yenisini kurunuz.</li>
                <li>Uygulama a\xE7\u0131ld\u0131\u011F\u0131nda kurye bilgilerinizle oturum a\xE7\u0131p \xE7a\u011Fr\u0131lar\u0131 almaya ba\u015Flayabilirsiniz.</li>
              </ol>
            </div>

            <p style="font-size: 12px; color: #64748b; margin-top: 20px; text-align: center;">
              Do\u011Frudan APK Ba\u011Flant\u0131s\u0131: <a href="${apkUrl}" style="color: #34d399; text-decoration: none; word-break: break-all;">${apkUrl}</a>
            </p>
          </td>
        </tr>
        <tr>
          <td style="background-color: #011410; padding: 20px 24px; text-align: center; border-top: 1px solid #064e3b;">
            <p style="margin: 0 0 6px 0; font-size: 12px; color: #94a3b8;">
              Antalya \u015Eehir \u0130\xE7i Moto Kurye Hizmetleri \u2022 7/24 Kesintisiz Teslimat
            </p>
            <p style="margin: 0; font-size: 12px; color: #64748b;">
              \u0130leti\u015Fim & Destek: <a href="mailto:kuryeantalyam@gmail.com" style="color: #34d399; text-decoration: none;">kuryeantalyam@gmail.com</a>
            </p>
          </td>
        </tr>
      </table>
    </body>
    </html>
    `;
    const info = await transporter.sendMail({
      from: fromAddress,
      to: recipient,
      subject: "Antalya Kurye Mobil Uygulamas\u0131 (APK) Yay\u0131nland\u0131 - Hemen \u0130ndirin \u{1F6B4}",
      html: htmlContent,
      headers: {
        "X-Priority": "1",
        "X-MSMail-Priority": "High"
      }
    });
    dbState.emailLogs.unshift({
      id: `mail-apk-${Date.now()}`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      orderId: "APK-PROMO",
      trackingCode: "APK-v1.5.0",
      recipients: [recipient],
      subject: "Antalya Kurye Mobil Uygulamas\u0131 (APK) Yay\u0131nland\u0131 - Hemen \u0130ndirin \u{1F6B4}",
      status: "sent",
      summary: `APK Tan\u0131t\u0131m Bildirimi -> ${recipient}`
    });
    if (dbState.emailLogs.length > 60) dbState.emailLogs = dbState.emailLogs.slice(0, 60);
    saveDatabase();
    res.json({
      success: true,
      message: `APK tan\u0131t\u0131m e-postas\u0131 ${recipient} adresine ba\u015Far\u0131yla iletildi.`,
      info
    });
  } catch (err) {
    console.error("Send APK promo email error:", err);
    res.status(500).json({ error: err.message || "E-posta g\xF6nderilemedi." });
  }
});
app.get("/api/couriers/emails", (req, res) => {
  const allRecipients = getRegisteredCourierEmails();
  const courierUsers = (dbState.users || []).filter((u) => u.role === "courier");
  res.json({
    success: true,
    allRecipients,
    courierUsers,
    extraEmails: dbState.extraCourierEmails || []
  });
});
app.post("/api/couriers/emails", (req, res) => {
  try {
    const { email } = req.body || {};
    if (!email || !email.includes("@")) {
      res.status(400).json({ error: "Ge\xE7ersiz e-posta adresi" });
      return;
    }
    const cleanEmail = email.trim().toLowerCase();
    if (!Array.isArray(dbState.extraCourierEmails)) {
      dbState.extraCourierEmails = [];
    }
    if (!dbState.extraCourierEmails.includes(cleanEmail)) {
      dbState.extraCourierEmails.push(cleanEmail);
      saveDatabase();
      if (serverFirestoreDb) {
        (0, import_firestore.setDoc)((0, import_firestore.doc)(serverFirestoreDb, "settings", "notifications"), { extraCourierEmails: dbState.extraCourierEmails }, { merge: true }).catch(() => {
        });
      }
    }
    res.json({
      success: true,
      extraEmails: dbState.extraCourierEmails,
      allRecipients: getRegisteredCourierEmails()
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.delete("/api/couriers/emails/:email", (req, res) => {
  try {
    const emailToDelete = decodeURIComponent(req.params.email).trim().toLowerCase();
    if (Array.isArray(dbState.extraCourierEmails)) {
      dbState.extraCourierEmails = dbState.extraCourierEmails.filter((em) => em.toLowerCase() !== emailToDelete);
      saveDatabase();
      if (serverFirestoreDb) {
        (0, import_firestore.setDoc)((0, import_firestore.doc)(serverFirestoreDb, "settings", "notifications"), { extraCourierEmails: dbState.extraCourierEmails }, { merge: true }).catch(() => {
        });
      }
    }
    res.json({
      success: true,
      extraEmails: dbState.extraCourierEmails || [],
      allRecipients: getRegisteredCourierEmails()
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.post("/api/notifications/send-order-email", (req, res) => {
  try {
    const { orderId } = req.body;
    const order = dbState.requests.find((r) => r.id === orderId);
    if (!order) {
      res.status(404).json({ error: "Sipari\u015F bulunamad\u0131" });
      return;
    }
    const result = enqueueNewOrderEmail(order, void 0, true);
    res.json({ success: true, result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.patch("/api/requests/:id", (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    const reqIndex = dbState.requests.findIndex((r) => r.id === id);
    if (reqIndex === -1) {
      res.status(404).json({ error: "Talep bulunamad\u0131" });
      return;
    }
    const current = dbState.requests[reqIndex];
    const updated = {
      ...current,
      ...updates,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (updates.status === "delivered" && current.status !== "delivered") {
      if (updated.assignedCourier?.id) {
        const courierUser = dbState.users.find((u) => u.id === updated.assignedCourier.id);
        if (courierUser) {
          courierUser.totalOrders = (courierUser.totalOrders || 0) + 1;
          courierUser.totalEarnings = (courierUser.totalEarnings || 0) + (updated.courierEarnings || 0);
        }
        const courierInfo = dbState.couriers.find((c) => c.id === updated.assignedCourier.id);
        if (courierInfo) {
          courierInfo.totalDeliveries = (courierInfo.totalDeliveries || 0) + 1;
        }
      }
    }
    dbState.requests[reqIndex] = updated;
    saveDatabase();
    if (serverFirestoreDb && updated.id) {
      (0, import_firestore.setDoc)((0, import_firestore.doc)(serverFirestoreDb, "delivery_requests", updated.id), JSON.parse(JSON.stringify(updated)), { merge: true }).catch(() => {
      });
    }
    res.json({ success: true, request: updated });
  } catch (err) {
    console.error("Error updating request:", err);
    res.status(500).json({ error: err.message || "Sunucu hatas\u0131" });
  }
});
app.post("/api/requests/:id/accept", (req, res) => {
  try {
    const { id } = req.params;
    const { courierId } = req.body;
    const reqIndex = dbState.requests.findIndex((r) => r.id === id);
    if (reqIndex === -1) {
      res.status(404).json({ error: "Talep bulunamad\u0131" });
      return;
    }
    let courier = dbState.couriers.find((c) => c.id === courierId);
    if (!courier && courierId) {
      const userCourier = dbState.users.find((u) => u.id === courierId && (u.role === "courier" || u.role === "admin"));
      if (userCourier) {
        courier = {
          id: userCourier.id,
          name: userCourier.name,
          phone: userCourier.phone,
          email: userCourier.email,
          district: userCourier.district || "Muratpa\u015Fa",
          rating: 5,
          totalDeliveries: userCourier.totalOrders || 0,
          currentLat: 36.886,
          currentLng: 30.7065
        };
        dbState.couriers.push(courier);
      }
    }
    if (!courier) {
      res.status(403).json({ error: "Sipari\u015Fi kabul etmek i\xE7in ge\xE7erli bir kurye giri\u015Fi gereklidir. Kurye olmayanlar havuzdan talep se\xE7emez." });
      return;
    }
    const nowIso = (/* @__PURE__ */ new Date()).toISOString();
    const updated = {
      ...dbState.requests[reqIndex],
      status: "courier_assigned",
      assignedCourier: courier,
      courier,
      acceptedAt: dbState.requests[reqIndex].acceptedAt || nowIso,
      updatedAt: nowIso
    };
    dbState.requests[reqIndex] = updated;
    saveDatabase();
    if (serverFirestoreDb && updated.id) {
      (0, import_firestore.setDoc)((0, import_firestore.doc)(serverFirestoreDb, "delivery_requests", updated.id), JSON.parse(JSON.stringify(updated)), { merge: true }).catch(() => {
      });
    }
    res.json({ success: true, request: updated });
  } catch (err) {
    console.error("Error accepting request:", err);
    res.status(500).json({ error: err.message || "Sunucu hatas\u0131" });
  }
});
app.post("/api/requests/:id/release", (req, res) => {
  try {
    const { id } = req.params;
    const reqIndex = dbState.requests.findIndex((r) => r.id === id || r.trackingCode === id);
    if (reqIndex === -1) {
      res.status(404).json({ error: "Talep bulunamad\u0131" });
      return;
    }
    const updated = {
      ...dbState.requests[reqIndex],
      status: "pending_pool",
      assignedCourier: void 0,
      courier: void 0,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    dbState.requests[reqIndex] = updated;
    saveDatabase();
    if (serverFirestoreDb && updated.id) {
      (0, import_firestore.setDoc)((0, import_firestore.doc)(serverFirestoreDb, "delivery_requests", updated.id), JSON.parse(JSON.stringify(updated)), { merge: true }).catch(() => {
      });
    }
    res.json({ success: true, request: updated });
  } catch (err) {
    console.error("Error releasing request:", err);
    res.status(500).json({ error: err.message || "Sunucu hatas\u0131" });
  }
});
app.post("/api/requests/:id/approve-pool", (req, res) => {
  try {
    const { id } = req.params;
    const reqIndex = dbState.requests.findIndex((r) => r.id === id || r.trackingCode === id);
    if (reqIndex === -1) {
      res.status(404).json({ error: "Talep bulunamad\u0131" });
      return;
    }
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const updated = {
      ...dbState.requests[reqIndex],
      status: "pending_pool",
      approvedAt: now,
      updatedAt: now
    };
    dbState.requests[reqIndex] = updated;
    saveDatabase();
    if (updated.id) dispatchedEmailOrderIds.delete(updated.id);
    if (updated.trackingCode) dispatchedEmailOrderIds.delete(updated.trackingCode);
    const queueResult = enqueueNewOrderEmail(updated, void 0, true);
    if (serverFirestoreDb && updated.id) {
      (0, import_firestore.setDoc)((0, import_firestore.doc)(serverFirestoreDb, "delivery_requests", updated.id), JSON.parse(JSON.stringify(updated)), { merge: true }).catch(() => {
      });
    }
    console.log(`[ORDER APPROVED TO POOL] ID: ${updated.id}, Tracking: ${updated.trackingCode}, Email Status: ${queueResult.status}`);
    res.json({ success: true, request: updated, queueResult });
  } catch (err) {
    console.error("Error approving request for pool:", err);
    res.status(500).json({ error: err.message || "Sunucu hatas\u0131" });
  }
});
app.post("/api/requests/:id/cancel", (req, res) => {
  try {
    const { id } = req.params;
    const reqIndex = dbState.requests.findIndex((r) => r.id === id || r.trackingCode === id);
    if (reqIndex === -1) {
      res.status(404).json({ error: "Talep bulunamad\u0131" });
      return;
    }
    const updated = {
      ...dbState.requests[reqIndex],
      status: "cancelled",
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    dbState.requests[reqIndex] = updated;
    saveDatabase();
    if (serverFirestoreDb && updated.id) {
      (0, import_firestore.setDoc)((0, import_firestore.doc)(serverFirestoreDb, "delivery_requests", updated.id), JSON.parse(JSON.stringify(updated)), { merge: true }).catch(() => {
      });
    }
    res.json({ success: true, request: updated });
  } catch (err) {
    console.error("Error cancelling request:", err);
    res.status(500).json({ error: err.message || "Sunucu hatas\u0131" });
  }
});
app.delete("/api/requests/:id", (req, res) => {
  try {
    const { id } = req.params;
    const reqIndex = dbState.requests.findIndex((r) => r.id === id || r.trackingCode === id);
    if (reqIndex === -1) {
      res.status(404).json({ error: "Talep bulunamad\u0131" });
      return;
    }
    const removed = dbState.requests.splice(reqIndex, 1)[0];
    saveDatabase();
    if (serverFirestoreDb && removed.id) {
      (0, import_firestore.setDoc)((0, import_firestore.doc)(serverFirestoreDb, "delivery_requests", removed.id), { status: "cancelled", isDeleted: true, updatedAt: (/* @__PURE__ */ new Date()).toISOString() }, { merge: true }).catch(() => {
      });
    }
    res.json({ success: true, removed });
  } catch (err) {
    console.error("Error deleting request:", err);
    res.status(500).json({ error: err.message || "Sunucu hatas\u0131" });
  }
});
app.post("/api/users", (req, res) => {
  try {
    const userData = req.body;
    if (!userData || !userData.name || !userData.phone) {
      res.status(400).json({ error: "Kullan\u0131c\u0131 bilgileri eksik" });
      return;
    }
    const newUser = {
      id: userData.id || `user-custom-${Date.now()}`,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      totalOrders: 0,
      totalEarnings: 0,
      isOnline: userData.role === "courier" ? true : void 0,
      ...userData
    };
    const existingIndex = dbState.users.findIndex((u) => u.id === newUser.id || newUser.email && u.email === newUser.email);
    if (existingIndex >= 0) {
      dbState.users[existingIndex] = { ...dbState.users[existingIndex], ...newUser };
    } else {
      dbState.users.push(newUser);
    }
    if (newUser.role === "courier") {
      const courierInfo = {
        id: newUser.id,
        name: newUser.name,
        phone: newUser.phone,
        email: newUser.email,
        district: newUser.district || "Muratpa\u015Fa",
        rating: 5,
        totalDeliveries: 0,
        currentLat: 36.886,
        currentLng: 30.7065
      };
      const existingCIndex = dbState.couriers.findIndex((c) => c.id === newUser.id);
      if (existingCIndex >= 0) {
        dbState.couriers[existingCIndex] = { ...dbState.couriers[existingCIndex], ...courierInfo };
      } else {
        dbState.couriers.push(courierInfo);
      }
    }
    saveDatabase();
    res.json({ success: true, user: newUser });
  } catch (err) {
    console.error("Error creating user:", err);
    res.status(500).json({ error: err.message || "Sunucu hatas\u0131" });
  }
});
app.post("/api/users/sync-batch", (req, res) => {
  try {
    const { users } = req.body || {};
    if (!Array.isArray(users)) {
      res.status(400).json({ error: "users dizisi bekleniyor." });
      return;
    }
    let changed = false;
    users.forEach((userData) => {
      if (!userData || !userData.id) return;
      const emailLower = (userData.email || "").trim().toLowerCase();
      const existingIndex = dbState.users.findIndex(
        (u) => u.id === userData.id || emailLower && u.email && u.email.trim().toLowerCase() === emailLower
      );
      if (existingIndex >= 0) {
        dbState.users[existingIndex] = { ...dbState.users[existingIndex], ...userData };
      } else {
        dbState.users.push(userData);
        changed = true;
      }
      if (userData.role === "courier") {
        const cIdx = dbState.couriers.findIndex(
          (c) => c.id === userData.id || emailLower && c.email && c.email.trim().toLowerCase() === emailLower
        );
        const courierInfo = {
          id: userData.id,
          name: userData.name,
          phone: userData.phone,
          email: userData.email,
          district: userData.district || "Muratpa\u015Fa",
          rating: userData.rating || 5,
          totalDeliveries: userData.totalDeliveries || userData.totalOrders || 0,
          currentLat: userData.currentLat || 36.886,
          currentLng: userData.currentLng || 30.7065,
          isOnline: userData.isOnline !== false
        };
        if (cIdx >= 0) {
          dbState.couriers[cIdx] = { ...dbState.couriers[cIdx], ...courierInfo };
        } else {
          dbState.couriers.push(courierInfo);
          changed = true;
        }
      }
    });
    if (changed) {
      saveDatabase();
    }
    const allRecipients = getRegisteredCourierEmails();
    res.json({
      success: true,
      syncedCount: users.length,
      allRecipients,
      courierCount: (dbState.users || []).filter((u) => u.role === "courier").length
    });
  } catch (err) {
    console.error("Error syncing batch users:", err);
    res.status(500).json({ error: err.message });
  }
});
app.patch("/api/users/:id", (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    const userIndex = dbState.users.findIndex((u) => u.id === id);
    if (userIndex === -1) {
      res.status(404).json({ error: "Kullan\u0131c\u0131 bulunamad\u0131" });
      return;
    }
    dbState.users[userIndex] = { ...dbState.users[userIndex], ...updates };
    const courierIndex = dbState.couriers.findIndex((c) => c.id === id);
    if (courierIndex >= 0) {
      dbState.couriers[courierIndex] = {
        ...dbState.couriers[courierIndex],
        name: updates.name || dbState.couriers[courierIndex].name,
        phone: updates.phone || dbState.couriers[courierIndex].phone,
        email: updates.email || dbState.couriers[courierIndex].email,
        district: updates.district || dbState.couriers[courierIndex].district
      };
    }
    saveDatabase();
    res.json({ success: true, user: dbState.users[userIndex] });
  } catch (err) {
    console.error("Error updating user:", err);
    res.status(500).json({ error: err.message || "Sunucu hatas\u0131" });
  }
});
app.delete("/api/users/:id", (req, res) => {
  try {
    const { id } = req.params;
    dbState.users = dbState.users.filter((u) => u.id !== id);
    dbState.couriers = dbState.couriers.filter((c) => c.id !== id);
    saveDatabase();
    res.json({ success: true });
  } catch (err) {
    console.error("Error deleting user:", err);
    res.status(500).json({ error: err.message || "Sunucu hatas\u0131" });
  }
});
async function processPasswordResetRequest(params) {
  const { emailOrIdentifier, role, userHint } = params;
  if (!emailOrIdentifier || !emailOrIdentifier.trim()) {
    return { success: false, status: 400, error: "L\xFCtfen kay\u0131tl\u0131 e-posta veya telefon numaran\u0131z\u0131 giriniz." };
  }
  const raw = String(emailOrIdentifier).trim().toLowerCase();
  const digitsOnly = raw.replace(/\D/g, "");
  let found = dbState.users.find((u) => {
    if (role && u.role !== role) return false;
    if (u.email && u.email.trim().toLowerCase() === raw) return true;
    if (digitsOnly.length >= 7) {
      const uDigits = (u.phone || "").replace(/\D/g, "");
      if (uDigits.endsWith(digitsOnly) || digitsOnly.endsWith(uDigits) || uDigits === digitsOnly) return true;
    }
    return false;
  });
  if (!found) {
    found = dbState.users.find((u) => {
      if (u.email && u.email.trim().toLowerCase() === raw) return true;
      if (digitsOnly.length >= 7) {
        const uDigits = (u.phone || "").replace(/\D/g, "");
        if (uDigits.endsWith(digitsOnly) || digitsOnly.endsWith(uDigits) || uDigits === digitsOnly) return true;
      }
      return false;
    });
  }
  if (!found && serverFirestoreDb) {
    try {
      const usersSnap = await (0, import_firestore.getDocs)((0, import_firestore.collection)(serverFirestoreDb, "users"));
      for (const docSnap of usersSnap.docs) {
        const d = docSnap.data();
        if (!d) continue;
        const dEmail = (d.email || "").trim().toLowerCase();
        const dPhoneDigits = (d.phone || "").replace(/\D/g, "");
        if (dEmail && dEmail === raw) {
          found = { ...d, id: docSnap.id };
          break;
        }
        if (digitsOnly.length >= 7 && (dPhoneDigits.endsWith(digitsOnly) || digitsOnly.endsWith(dPhoneDigits) || dPhoneDigits === digitsOnly)) {
          found = { ...d, id: docSnap.id };
          break;
        }
      }
      if (!found) {
        const couriersSnap = await (0, import_firestore.getDocs)((0, import_firestore.collection)(serverFirestoreDb, "couriers"));
        for (const docSnap of couriersSnap.docs) {
          const d = docSnap.data();
          if (!d) continue;
          const dEmail = (d.email || "").trim().toLowerCase();
          const dPhoneDigits = (d.phone || "").replace(/\D/g, "");
          if (dEmail && dEmail === raw) {
            found = { ...d, id: docSnap.id, role: "courier" };
            break;
          }
          if (digitsOnly.length >= 7 && (dPhoneDigits.endsWith(digitsOnly) || digitsOnly.endsWith(dPhoneDigits) || dPhoneDigits === digitsOnly)) {
            found = { ...d, id: docSnap.id, role: "courier" };
            break;
          }
        }
      }
      if (found) {
        const existingIdx = dbState.users.findIndex((x) => x.id === found.id || found.email && x.email === found.email);
        if (existingIdx >= 0) dbState.users[existingIdx] = { ...dbState.users[existingIdx], ...found };
        else dbState.users.push(found);
      }
    } catch (fErr) {
      console.warn("[FORGOT PASSWORD FIRESTORE LOOKUP ERR]", fErr?.message);
    }
  }
  if (!found && userHint && userHint.email) {
    found = userHint;
  }
  if (!found) {
    return {
      success: false,
      status: 404,
      error: "Bu bilgilere ait kay\u0131tl\u0131 kullan\u0131c\u0131 bulunamad\u0131. L\xFCtfen e-posta veya telefon bilginizi kontrol ediniz."
    };
  }
  const targetEmail = (found.email || "").trim();
  if (!targetEmail || !targetEmail.includes("@")) {
    return {
      success: false,
      status: 400,
      error: "Kullan\u0131c\u0131n\u0131n kay\u0131tl\u0131 ge\xE7erli bir e-posta adresi bulunmuyor. L\xFCtfen destek hatt\u0131m\u0131zla (0507 754 74 84) ileti\u015Fime ge\xE7iniz."
    };
  }
  const userName = found.name || "De\u011Ferli Kullan\u0131c\u0131m\u0131z";
  const userRoleText = found.role === "courier" ? "Moto Kurye Hesab\u0131" : found.role === "admin" ? "Y\xF6netici Hesab\u0131" : "M\xFC\u015Fteri Hesab\u0131";
  const userPassword = (found.password || found.sifre || found.pass || "1234").trim();
  const refCode = Math.floor(1e5 + Math.random() * 9e5);
  const now = /* @__PURE__ */ new Date();
  const timeStr = now.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const dateStr = now.toLocaleDateString("tr-TR", { day: "2-digit", month: "2-digit", year: "numeric" });
  const cfg = dbState.smtpConfig;
  const smtpUser = (cfg?.user || "kuryeantalyam@gmail.com").trim();
  const smtpPass = (cfg?.pass || "tlnsrezkaobytsvg").replace(/\s+/g, "").trim();
  const fromName = cfg?.fromName || "Antalya \u015Eehir \u0130\xE7i Teslimat 7/24";
  const fromAddress = `"${fromName}" <${smtpUser}>`;
  const isSelfSent = targetEmail.toLowerCase() === smtpUser.toLowerCase();
  const subject = `Antalya Kurye Ekspres: \u015Eifre Hat\u0131rlatma Bilgileriniz (#${refCode})`;
  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body style="margin: 0; padding: 20px 10px; background-color: #f1f5f9; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #1e293b;">
      <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 580px; margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);">
        <!-- Header -->
        <tr>
          <td style="background-color: #047857; padding: 24px 20px; text-align: center;">
            <h1 style="margin: 0; font-size: 20px; font-weight: 700; color: #ffffff; letter-spacing: 0.3px;">Antalya \u015Eehir \u0130\xE7i Moto Kurye</h1>
            <p style="margin: 4px 0 0 0; font-size: 13px; color: #d1fae5;">\u015Eifre Hat\u0131rlatma Bildirimi</p>
          </td>
        </tr>
        
        <!-- Content -->
        <tr>
          <td style="padding: 28px 24px;">
            <p style="font-size: 15px; margin-top: 0; color: #0f172a; font-weight: 600;">Merhaba Say\u0131n ${userName},</p>
            <p style="font-size: 14px; line-height: 1.6; color: #334155; margin-bottom: 20px;">
              Antalya Kurye Ekspres platformundaki hesab\u0131n\u0131z i\xE7in \u015Fifre hat\u0131rlatma talebinde bulundunuz. Kay\u0131tl\u0131 hesap bilgileriniz ve \u015Fifreniz a\u015Fa\u011F\u0131da yer almaktad\u0131r:
            </p>
            
            <!-- Info Box -->
            <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f8fafc; border: 1px solid #cbd5e1; border-radius: 8px; margin: 16px 0; padding: 16px;">
              <tr>
                <td style="padding: 6px 0; color: #64748b; font-size: 13px; width: 130px; font-weight: 600;">Hesap T\xFCr\xFC:</td>
                <td style="padding: 6px 0; color: #0f172a; font-size: 13px; font-weight: 700;">${userRoleText}</td>
              </tr>
              <tr>
                <td style="padding: 6px 0; color: #64748b; font-size: 13px; font-weight: 600;">E-Posta:</td>
                <td style="padding: 6px 0; color: #0f172a; font-size: 13px; font-weight: 600;">${targetEmail}</td>
              </tr>
              ${found.phone ? `
              <tr>
                <td style="padding: 6px 0; color: #64748b; font-size: 13px; font-weight: 600;">Telefon:</td>
                <td style="padding: 6px 0; color: #0f172a; font-size: 13px;">${found.phone}</td>
              </tr>` : ""}
              <tr>
                <td style="padding: 12px 0 4px 0; color: #047857; font-size: 14px; font-weight: 700;">Giri\u015F \u015Eifreniz:</td>
                <td style="padding: 12px 0 4px 0;">
                  <span style="display: inline-block; background-color: #ecfdf5; border: 1.5px solid #059669; color: #065f46; font-size: 18px; font-weight: 800; padding: 6px 14px; border-radius: 6px; letter-spacing: 1px;">
                    ${userPassword}
                  </span>
                </td>
              </tr>
            </table>

            <!-- Notice -->
            <div style="background-color: #fef3c7; border-left: 4px solid #f59e0b; padding: 12px 14px; border-radius: 4px; margin: 20px 0;">
              <p style="margin: 0; font-size: 12px; color: #92400e; line-height: 1.5;">
                <strong>G\xFCvenlik Uyar\u0131s\u0131:</strong> Bu talebi siz ger\xE7ekle\u015Ftirmediyseniz l\xFCtfen m\xFC\u015Fteri hizmetlerimiz ile (0507 754 74 84) ileti\u015Fime ge\xE7iniz. Giri\u015F yapt\u0131ktan sonra \u015Fifrenizi profil ayarlar\u0131n\u0131zdan de\u011Fi\u015Ftirebilirsiniz.
              </p>
            </div>

            <p style="font-size: 12px; color: #94a3b8; text-align: center; margin: 20px 0 0 0;">
              G\xFCvenlik Do\u011Frulama: <strong>#${refCode}</strong> \u2022 ${dateStr} ${timeStr}
            </p>
          </td>
        </tr>

        <!-- Footer -->
        <tr>
          <td style="background-color: #f8fafc; padding: 16px; text-align: center; border-top: 1px solid #e2e8f0; font-size: 12px; color: #64748b;">
            \xA9 ${now.getFullYear()} Antalya \u015Eehir \u0130\xE7i Moto Kurye & Teslimat A.\u015E.<br>
            Destek: <strong>0507 754 74 84</strong> \u2022 <a href="mailto:kuryeantalyam@gmail.com" style="color: #047857; text-decoration: none;">kuryeantalyam@gmail.com</a>
          </td>
        </tr>
      </table>
    </body>
    </html>
  `;
  const textContent = `
Antalya \u015Eehir \u0130\xE7i Moto Kurye - \u015Eifre Hat\u0131rlatma

Merhaba Say\u0131n ${userName},

Hesab\u0131n\u0131z i\xE7in \u015Fifre hat\u0131rlatma talebinde bulundunuz.

Hesap T\xFCr\xFC: ${userRoleText}
Kay\u0131tl\u0131 E-Posta: ${targetEmail}
\u015Eifreniz: ${userPassword}

G\xFCvenlik Referans Kodu: #${refCode} (${dateStr} ${timeStr})

Bu talebi siz yapmad\u0131ysan\u0131z l\xFCtfen dikkate almay\u0131n\u0131z.
Destek & \u0130leti\u015Fim: 0507 754 74 84 | kuryeantalyam@gmail.com
  `.trim();
  console.log(`[PASSWORD RESET REQUEST] Processing for: ${emailOrIdentifier}, targetEmail: ${targetEmail}`);
  const mailDetails = getMailTransporter();
  const transporter = mailDetails.transporter;
  let sentReal = false;
  let errDetail = "";
  let sendResultInfo = null;
  try {
    if (!transporter) throw new Error("SMTP transporter is not configured");
    sendResultInfo = await transporter.sendMail({
      from: fromAddress,
      to: targetEmail,
      replyTo: smtpUser,
      subject,
      text: textContent,
      html: htmlContent,
      priority: "high",
      headers: {
        "X-Priority": "1",
        "X-MSMail-Priority": "High",
        "Importance": "high"
      }
    });
    sentReal = true;
    console.log(`[PASSWORD RESET] Email sent successfully to ${targetEmail}. Google SMTP response: ${sendResultInfo?.response}`);
    dbState.emailLogs.unshift({
      id: `mail-pwd-${Date.now()}-${refCode}`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      orderId: `pwd-reset-${found.id || "user"}`,
      trackingCode: `REF-${refCode}`,
      recipients: [targetEmail],
      subject,
      status: "sent",
      summary: `\u015Eifre Hat\u0131rlatma (${userRoleText}) -> ${targetEmail}`,
      response: sendResultInfo?.response || "250 OK"
    });
    if (dbState.emailLogs.length > 60) dbState.emailLogs = dbState.emailLogs.slice(0, 60);
    saveDatabase();
  } catch (sendErr) {
    console.error(`[PASSWORD RESET FAIL] Error delivering email:`, sendErr);
    errDetail = sendErr?.message || "SMTP iletim hatas\u0131";
    dbState.emailLogs.unshift({
      id: `mail-pwd-${Date.now()}-${refCode}`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      orderId: `pwd-reset-${found.id || "user"}`,
      trackingCode: `REF-${refCode}`,
      recipients: [targetEmail],
      subject,
      status: "failed",
      summary: `\u015Eifre Hat\u0131rlatma Ba\u015Far\u0131s\u0131z: ${errDetail}`
    });
    saveDatabase();
  }
  if (!sentReal) {
    return {
      success: false,
      status: 500,
      error: `E-posta sunucusuna ba\u011Flan\u0131rken hata olu\u015Ftu: ${errDetail}. L\xFCtfen destek hatt\u0131m\u0131zla (0507 754 74 84) ileti\u015Fime ge\xE7iniz.`
    };
  }
  return {
    success: true,
    email: targetEmail,
    sentReal: true,
    refCode,
    isSelfSent,
    userName,
    userRole: found.role,
    message: `\u015Eifre hat\u0131rlatma bilgileri ${targetEmail} adresinize ba\u015Far\u0131yla iletildi.`
  };
}
app.post("/api/auth/forgot-password", async (req, res) => {
  try {
    const { emailOrIdentifier, role, userHint } = req.body || {};
    const result = await processPasswordResetRequest({ emailOrIdentifier, role, userHint });
    if (result.success) {
      res.json(result);
    } else {
      res.status(result.status || 400).json({ error: result.error || result.message });
    }
  } catch (err) {
    console.error("Forgot password error:", err);
    res.status(500).json({ error: err.message || "Sunucu hatas\u0131 olu\u015Ftu." });
  }
});
app.post("/api/couriers/location", (req, res) => {
  try {
    const { courierId, lat, lng } = req.body;
    const courier = dbState.couriers.find((c) => c.id === courierId);
    if (courier && typeof lat === "number" && typeof lng === "number") {
      courier.currentLat = lat;
      courier.currentLng = lng;
      res.json({ success: true });
    } else {
      res.json({ success: false });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.post("/api/database/backup", (req, res) => {
  try {
    const { data } = req.body;
    if (data && Array.isArray(data.users) && Array.isArray(data.requests)) {
      dbState = {
        users: data.users,
        couriers: data.couriers || DEFAULT_COURIERS,
        requests: data.requests,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      saveDatabase();
      res.json({ success: true });
    } else {
      res.status(400).json({ error: "Ge\xE7ersiz yedek verisi" });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.post("/api/analytics/visit", (req, res) => {
  try {
    const { visitorId, path: pagePath, referrer, device } = req.body || {};
    if (!dbState.visitorStats) {
      dbState.visitorStats = { ...DEFAULT_VISITOR_STATS };
    }
    const todayStr = getTodayDateStr();
    if (dbState.visitorStats.todayDate !== todayStr) {
      dbState.visitorStats.todayDate = todayStr;
      dbState.visitorStats.todayVisits = 0;
      dbState.visitorStats.todayVisitorIds = [];
    }
    const vId = typeof visitorId === "string" && visitorId.trim() ? visitorId.trim() : `anon_${Date.now()}`;
    const isUniqueEver = !dbState.visitorStats.uniqueVisitorIds.includes(vId);
    const isUniqueToday = !dbState.visitorStats.todayVisitorIds.includes(vId);
    dbState.visitorStats.totalVisits = (dbState.visitorStats.totalVisits || 0) + 1;
    dbState.visitorStats.todayVisits = (dbState.visitorStats.todayVisits || 0) + 1;
    if (isUniqueEver) {
      dbState.visitorStats.uniqueVisitors = (dbState.visitorStats.uniqueVisitors || 0) + 1;
      dbState.visitorStats.uniqueVisitorIds.push(vId);
      if (dbState.visitorStats.uniqueVisitorIds.length > 5e3) {
        dbState.visitorStats.uniqueVisitorIds = dbState.visitorStats.uniqueVisitorIds.slice(-5e3);
      }
    }
    if (isUniqueToday) {
      dbState.visitorStats.todayVisitorIds.push(vId);
      if (dbState.visitorStats.todayVisitorIds.length > 2e3) {
        dbState.visitorStats.todayVisitorIds = dbState.visitorStats.todayVisitorIds.slice(-2e3);
      }
    }
    let detectedDevice = "desktop";
    const userAgent = req.headers["user-agent"] || "";
    if (device === "mobile" || /Android|iPhone|iPod|Mobile/i.test(userAgent)) {
      detectedDevice = "mobile";
    } else if (device === "tablet" || /iPad|Tablet/i.test(userAgent)) {
      detectedDevice = "tablet";
    }
    const nowIso = (/* @__PURE__ */ new Date()).toISOString();
    dbState.visitorStats.lastVisitAt = nowIso;
    const newRecord = {
      id: `vis_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp: nowIso,
      path: typeof pagePath === "string" && pagePath ? pagePath.slice(0, 100) : "/",
      deviceType: detectedDevice,
      referrer: typeof referrer === "string" && referrer ? referrer.slice(0, 150) : void 0,
      isUnique: isUniqueEver
    };
    if (!Array.isArray(dbState.visitorStats.recentVisitors)) {
      dbState.visitorStats.recentVisitors = [];
    }
    dbState.visitorStats.recentVisitors.unshift(newRecord);
    if (dbState.visitorStats.recentVisitors.length > 50) {
      dbState.visitorStats.recentVisitors = dbState.visitorStats.recentVisitors.slice(0, 50);
    }
    saveDatabase();
    if (serverFirestoreDb) {
      (0, import_firestore.setDoc)(
        (0, import_firestore.doc)(serverFirestoreDb, "settings", "site_counter"),
        {
          totalVisits: dbState.visitorStats.totalVisits,
          uniqueVisitors: dbState.visitorStats.uniqueVisitors,
          todayVisits: dbState.visitorStats.todayVisits,
          todayDate: dbState.visitorStats.todayDate,
          lastVisitAt: dbState.visitorStats.lastVisitAt,
          updatedAt: nowIso
        },
        { merge: true }
      ).catch(() => {
      });
    }
    const tenMinutesAgo = Date.now() - 10 * 60 * 1e3;
    const activeNow = dbState.visitorStats.recentVisitors.filter(
      (v) => new Date(v.timestamp).getTime() >= tenMinutesAgo
    ).length;
    res.json({
      success: true,
      stats: {
        totalVisits: dbState.visitorStats.totalVisits,
        uniqueVisitors: dbState.visitorStats.uniqueVisitors,
        todayVisits: dbState.visitorStats.todayVisits,
        todayDate: dbState.visitorStats.todayDate,
        lastVisitAt: dbState.visitorStats.lastVisitAt,
        activeNow: Math.max(1, activeNow),
        recentVisitors: dbState.visitorStats.recentVisitors.slice(0, 20)
      }
    });
  } catch (err) {
    console.error("[ANALYTICS] Error logging visit:", err);
    res.status(500).json({ error: err.message });
  }
});
app.get("/api/analytics/stats", (req, res) => {
  try {
    if (!dbState.visitorStats) {
      dbState.visitorStats = { ...DEFAULT_VISITOR_STATS };
    }
    const todayStr = getTodayDateStr();
    if (dbState.visitorStats.todayDate !== todayStr) {
      dbState.visitorStats.todayDate = todayStr;
      dbState.visitorStats.todayVisits = 0;
      dbState.visitorStats.todayVisitorIds = [];
      saveDatabase();
    }
    const tenMinutesAgo = Date.now() - 10 * 60 * 1e3;
    const recentList = dbState.visitorStats.recentVisitors || [];
    const activeNow = recentList.filter(
      (v) => new Date(v.timestamp).getTime() >= tenMinutesAgo
    ).length;
    res.json({
      success: true,
      stats: {
        totalVisits: dbState.visitorStats.totalVisits || 0,
        uniqueVisitors: dbState.visitorStats.uniqueVisitors || 0,
        todayVisits: dbState.visitorStats.todayVisits || 0,
        todayDate: dbState.visitorStats.todayDate,
        lastVisitAt: dbState.visitorStats.lastVisitAt,
        activeNow: Math.max(1, activeNow),
        recentVisitors: recentList.slice(0, 30)
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.post("/api/analytics/reset", (req, res) => {
  try {
    const { initialVisits } = req.body || {};
    const count = typeof initialVisits === "number" && initialVisits >= 0 ? initialVisits : 0;
    const todayStr = getTodayDateStr();
    dbState.visitorStats = {
      totalVisits: count,
      uniqueVisitors: count > 0 ? Math.round(count * 0.75) : 0,
      todayVisits: count > 0 ? Math.min(count, 5) : 0,
      todayDate: todayStr,
      uniqueVisitorIds: [],
      todayVisitorIds: [],
      lastVisitAt: (/* @__PURE__ */ new Date()).toISOString(),
      recentVisitors: []
    };
    saveDatabase();
    res.json({
      success: true,
      message: "Site sayac\u0131 ba\u015Far\u0131yla s\u0131f\u0131rland\u0131.",
      stats: {
        totalVisits: dbState.visitorStats.totalVisits,
        uniqueVisitors: dbState.visitorStats.uniqueVisitors,
        todayVisits: dbState.visitorStats.todayVisits,
        todayDate: dbState.visitorStats.todayDate,
        lastVisitAt: dbState.visitorStats.lastVisitAt,
        activeNow: 1,
        recentVisitors: []
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
function detectAntalyaDistrict(text) {
  const lower = (text || "").toLowerCase();
  if (lower.includes("lara") || lower.includes("g\xFCzeloba") || lower.includes("\xF6rnekk\xF6y") || lower.includes("kundu") || lower.includes("bar\u0131naklar")) {
    return "Lara (Muratpa\u015Fa)";
  }
  if (lower.includes("konyaalt\u0131") || lower.includes("konyaalti") || lower.includes("g\xFCrsu") || lower.includes("alt\u0131nkum") || lower.includes("toros") || lower.includes("uncal\u0131") || lower.includes("uncali") || lower.includes("arapsuyu") || lower.includes("liman") || lower.includes("hurma") || lower.includes("sar\u0131su") || lower.includes("sarisu") || lower.includes("ulu\xE7") || lower.includes("uluc") || lower.includes("molla yusuf")) {
    return "Konyaalt\u0131";
  }
  if (lower.includes("kepez") || lower.includes("dokuma") || lower.includes("varsak") || lower.includes("ye\u015Filyurt") || lower.includes("yesilyurt") || lower.includes("k\xFClt\xFCr") || lower.includes("kultur") || lower.includes("\u015Fafak") || lower.includes("safak") || lower.includes("bar\u0131\u015F") || lower.includes("baris") || lower.includes("fabrikalar") || lower.includes("g\xFClveren") || lower.includes("gulveren")) {
    return "Kepez";
  }
  return "Muratpa\u015Fa";
}
function parseTurkishPhoneNumber(text) {
  if (!text) return null;
  const cleanDigits = text.replace(/\D/g, "");
  if (cleanDigits.length >= 10) {
    let num = cleanDigits;
    if (num.startsWith("90")) num = num.slice(2);
    if (!num.startsWith("0") && num.length === 10) num = "0" + num;
    if (num.length >= 11 && num.startsWith("05")) {
      return num.slice(0, 11).replace(/(\d{4})(\d{3})(\d{2})(\d{2})/, "$1 $2 $3 $4");
    }
  }
  const wordMap = {
    "s\u0131f\u0131r": "0",
    "sifir": "0",
    "bir": "1",
    "iki": "2",
    "\xFC\xE7": "3",
    "uc": "3",
    "d\xF6rt": "4",
    "dort": "4",
    "be\u015F": "5",
    "bes": "5",
    "alt\u0131": "6",
    "alti": "6",
    "yedi": "7",
    "sekiz": "8",
    "dokuz": "9",
    "on": "1",
    "yirmi": "2",
    "otuz": "3",
    "k\u0131rk": "4",
    "kirk": "4",
    "elli": "5",
    "altm\u0131\u015F": "6",
    "altmis": "6",
    "yetmi\u015F": "7",
    "yetmis": "7",
    "seksen": "8",
    "doksan": "9",
    "y\xFCz": "",
    "yuz": ""
  };
  const tokens = text.toLowerCase().split(/[\s,.-]+/);
  let digitStr = "";
  for (const token of tokens) {
    if (wordMap[token] !== void 0) {
      digitStr += wordMap[token];
    } else if (/^\d+$/.test(token)) {
      digitStr += token;
    }
  }
  if (digitStr.length >= 10) {
    if (!digitStr.startsWith("0")) digitStr = "0" + digitStr;
    if (digitStr.length >= 11 && digitStr.startsWith("05")) {
      return digitStr.slice(0, 11).replace(/(\d{4})(\d{3})(\d{2})(\d{2})/, "$1 $2 $3 $4");
    }
  }
  return null;
}
function calculateEstimatedPrice(fromDist, toDist) {
  if (fromDist === toDist) return 150;
  return 180;
}
app.post("/api/ai-voice/chat", async (req, res) => {
  try {
    const { message = "", state = {} } = req.body;
    const userText = (message || "").trim();
    const currentState = {
      step: state.step || "greeting",
      pickupAddress: state.pickupAddress || "",
      pickupDistrict: state.pickupDistrict || "",
      destAddress: state.destAddress || "",
      destDistrict: state.destDistrict || "",
      packageContent: state.packageContent || "",
      phone: state.phone || "",
      customerName: state.customerName || "De\u011Ferli M\xFC\u015Fterimiz",
      estimatedPrice: state.estimatedPrice || 150,
      estimatedDistanceKm: state.estimatedDistanceKm || 8,
      estimatedDurationMins: state.estimatedDurationMins || 35
    };
    const cleanCustomerServiceSpeech = (rawText, step) => {
      if (!rawText) return { text: "" };
      let cleaned = rawText.replace(/\b(harika|acaba)\b[.,!?]?/gi, "").replace(/\s+/g, " ").trim();
      const lower2 = cleaned.toLowerCase();
      if (lower2.includes("mail") || lower2.includes("e-posta") || lower2.includes("eposta") || lower2.includes("onay kodu") || lower2.includes("g\xFCvenlik kodu") || lower2.includes("do\u011Frulama kodu") || lower2.includes("kodunuz") || lower2.includes("4 haneli") || lower2.includes("kodu gir") || lower2.includes("kodu s\xF6yle")) {
        cleaned = "Onayl\u0131yorsan\u0131z adresinize hemen en yak\u0131n kuryeyi y\xF6nlendirece\u011Fim.";
        return { text: cleaned, step: "confirm" };
      }
      if (cleaned.length > 0) {
        cleaned = cleaned.charAt(0).toUpperCase() + cleaned.slice(1);
      }
      return { text: cleaned, step };
    };
    if (geminiClient && userText) {
      try {
        const systemPrompt = `Sen Antalya Kurye (antalyateslimat.com) m\xFC\u015Fteri hizmetleri sesli temsilcisisin. H\u0131zl\u0131, dinamik ve profesyonel bir erkek m\xFC\u015Fteri temsilcisi olarak konu\u015Fursun.
G\xF6revin sesli olarak kullan\u0131c\u0131yla konu\u015Fup Antalya i\xE7inde moto kurye y\xF6nlendirmektir.
Sipari\u015F Ad\u0131mlar\u0131:
1. Al\u0131\u015F Adresi (Nereden al\u0131nacak?)
2. Teslimat Adresi (Nereye g\xF6t\xFCr\xFClecek?)
3. Paket \u0130\xE7eri\u011Fi (Paketin i\xE7eri\u011Fi nedir?)
4. \u0130leti\u015Fim Telefonu (05XX XXX XX XX)
5. Onay ('Onayl\u0131yorsan\u0131z adresinize hemen en yak\u0131n kuryeyi y\xF6nlendirece\u011Fim.')

KES\u0130NL\u0130KLE UYULMASI GEREKEN ZORUNLU KURALLAR:
- ASLA VE KES\u0130NL\u0130KLE e-posta (email, mail adresi) \u0130STEME! E-posta sormak KES\u0130NL\u0130KLE YASAKTIR.
- ASLA VE KES\u0130NL\u0130KLE onay kodu, g\xFCvenlik kodu, do\u011Frulama kodu, SMS kodu veya PIN kodu SORMAMA VE \u0130STEMEME! Kod sormak KES\u0130NL\u0130KLE YASAKTIR.
- Telefon numaras\u0131 al\u0131nd\u0131ktan sonra ba\u015Fka hi\xE7bir \u015Fey sorma! Do\u011Frudan sadece \u015Funu s\xF6yle: 'Onayl\u0131yorsan\u0131z adresinize hemen en yak\u0131n kuryeyi y\xF6nlendirece\u011Fim.' ve step: 'confirm' yap.
- Onay a\u015Famas\u0131nda kullan\u0131c\u0131 'evet', 'onayl\u0131yorum', 'tamam', '\xE7a\u011F\u0131r', 'g\xF6nder' gibi bir onay verirse do\u011Frudan: 'Sipari\u015Finiz olu\u015Fturuldu, en yak\u0131n kuryemiz hemen y\xF6nlendirildi. Sizi m\xFC\u015Fteri panelinize aktar\u0131yorum, iyi g\xFCnler dilerim!' de, shouldCreateOrder: true ve step: 'completed' yap.
- 'n\xF6bet\xE7i' kelimesini asla kullanma, sadece 'kurye' de.
- 'harika', 'acaba' kelimelerini KES\u0130NL\u0130KLE kullanma! Do\u011Frudan, profesyonel, net ve kibar konu\u015F.
- A\xE7\u0131l\u0131\u015F sorusu: 'Adresinize hemen kurye g\xF6nderebilirim. Paketiniz nereden, hangi mahalle veya adresten al\u0131nacak?'
- Al\u0131\u015F adresi al\u0131nd\u0131ktan sonra sadece \u015Funu sor: 'Paketiniz nereye, hangi adrese teslim edilecek?' (kesinlikle adres tekrar\u0131 yapma).
- Teslimat adresi al\u0131nd\u0131ktan sonra kesinlikle sadece \u015Funu sor: 'Paketinizin i\xE7eri\u011Fi nedir?'
- Paket i\xE7eri\u011Fi sorulduktan sonra 'anlad\u0131m' deme, i\xE7eri\u011Fi tekrarlama! Do\u011Frudan sadece \u015Funu sor: 'Kuryemizin size ula\u015Fabilmesi ve takip SMS'i i\xE7in telefon numaran\u0131z nedir?'
- Onay a\u015Famas\u0131nda sipari\u015F \xF6zetindeki detaylar\u0131 okuma! Sadece \u015Funu s\xF6yle: 'Onayl\u0131yorsan\u0131z adresinize hemen en yak\u0131n kuryeyi y\xF6nlendirece\u011Fim.'
Antalya il\xE7eleri: Muratpa\u015Fa, Konyaalt\u0131, Kepez, Lara (Muratpa\u015Fa).

\u015Eu anki durum: ${JSON.stringify(currentState)}
Kullan\u0131c\u0131n\u0131n son s\xF6yledi\u011Fi: "${userText}"

JSON format\u0131nda yan\u0131t ver:
{
  "replyText": "Kullan\u0131c\u0131ya sesli s\xF6ylenecek samimi, profesyonel T\xFCrk\xE7e c\xFCmle",
  "step": "ask_pickup" | "ask_destination" | "ask_package_content" | "ask_phone" | "confirm" | "completed",
  "pickupAddress": "adres metni veya mevcut",
  "pickupDistrict": "Muratpa\u015Fa" | "Konyaalt\u0131" | "Kepez" | "Lara (Muratpa\u015Fa)",
  "destAddress": "adres metni veya mevcut",
  "destDistrict": "Muratpa\u015Fa" | "Konyaalt\u0131" | "Kepez" | "Lara (Muratpa\u015Fa)",
  "packageContent": "paket i\xE7eri\u011Fi veya mevcut",
  "phone": "05XX XXX XX XX veya mevcut",
  "shouldCreateOrder": true | false
}`;
        const geminiPromise = geminiClient.models.generateContent({
          model: "gemini-2.5-flash",
          contents: systemPrompt,
          config: {
            responseMimeType: "application/json",
            temperature: 0.2
          }
        });
        const timeoutPromise = new Promise(
          (_, reject) => setTimeout(() => reject(new Error("Gemini timeout")), 2500)
        );
        const geminiRes = await Promise.race([geminiPromise, timeoutPromise]);
        const rawJson = geminiRes?.text?.trim() || "";
        if (rawJson) {
          const parsed = JSON.parse(rawJson);
          let targetStep = parsed.step || currentState.step;
          if (targetStep === "ask_email" || targetStep === "ask_code") {
            targetStep = "confirm";
          }
          const sanitized2 = cleanCustomerServiceSpeech(parsed.replyText, targetStep);
          if (sanitized2.step) {
            targetStep = sanitized2.step;
          }
          return res.json({
            success: true,
            replyText: sanitized2.text,
            state: {
              step: targetStep,
              pickupAddress: parsed.pickupAddress || currentState.pickupAddress,
              pickupDistrict: parsed.pickupDistrict || currentState.pickupDistrict || "Muratpa\u015Fa",
              destAddress: parsed.destAddress || currentState.destAddress,
              destDistrict: parsed.destDistrict || currentState.destDistrict || "Muratpa\u015Fa",
              packageContent: parsed.packageContent || currentState.packageContent,
              phone: parsed.phone || currentState.phone,
              customerName: currentState.customerName,
              estimatedPrice: calculateEstimatedPrice(parsed.pickupDistrict || "Muratpa\u015Fa", parsed.destDistrict || "Muratpa\u015Fa"),
              estimatedDistanceKm: 10,
              estimatedDurationMins: 35
            },
            shouldCreateOrder: Boolean(parsed.shouldCreateOrder) || targetStep === "completed"
          });
        }
      } catch (geminiErr) {
        console.warn("[GEMINI AI CHAT FALLBACK TO DETERMINISTIC ENGINE]", geminiErr.message);
      }
    }
    const lower = userText.toLowerCase();
    let replyText = "";
    let shouldCreateOrder = false;
    if (lower.includes("iptal") || lower.includes("vazge\xE7tim") || lower.includes("kapat")) {
      return res.json({
        success: true,
        replyText: "Talebiniz iptal edildi. Yeni bir kurye \xE7a\u011F\u0131rmak isterseniz mikrofona dokunarak bana seslenebilirsiniz. \u0130yi g\xFCnler dilerim!",
        state: { ...currentState, step: "greeting" },
        shouldCreateOrder: false
      });
    }
    if (!userText || currentState.step === "greeting" || currentState.step === "ask_pickup") {
      if (!currentState.pickupAddress && !userText) {
        replyText = "Adresinize hemen kurye g\xF6nderebilirim. Paketiniz nereden, hangi mahalle veya adresten al\u0131nacak?";
        currentState.step = "ask_pickup";
      } else if (!currentState.pickupAddress && userText) {
        currentState.pickupAddress = userText;
        currentState.pickupDistrict = detectAntalyaDistrict(userText);
        currentState.step = "ask_destination";
        replyText = "Paketiniz nereye, hangi adrese teslim edilecek?";
      } else {
        currentState.step = "ask_destination";
        replyText = "Paketiniz nereye, hangi adrese teslim edilecek?";
      }
    } else if (currentState.step === "ask_destination") {
      if (!currentState.destAddress) {
        currentState.destAddress = userText;
        currentState.destDistrict = detectAntalyaDistrict(userText);
      }
      currentState.step = "ask_package_content";
      replyText = "Paketinizin i\xE7eri\u011Fi nedir?";
    } else if (currentState.step === "ask_package_content") {
      currentState.packageContent = userText.trim();
      currentState.step = "ask_phone";
      replyText = "Kuryemizin size kolayca ula\u015Fabilmesi i\xE7in telefon numaran\u0131z\u0131 \xF6\u011Frenebilir miyim?";
    } else if (currentState.step === "ask_phone") {
      const extractedPhone = parseTurkishPhoneNumber(userText);
      if (extractedPhone) {
        currentState.phone = extractedPhone;
      } else if (userText.replace(/\D/g, "").length >= 7) {
        currentState.phone = userText.trim();
      } else {
        currentState.phone = "0500 000 00 00";
      }
      currentState.estimatedPrice = calculateEstimatedPrice(currentState.pickupDistrict, currentState.destDistrict);
      currentState.step = "confirm";
      replyText = "Bilgilerinizi ald\u0131m. Onayl\u0131yorsan\u0131z adresinize hemen en yak\u0131n kuryeyi y\xF6nlendirece\u011Fim.";
    } else if (currentState.step === "confirm" || currentState.step === "ask_email" || currentState.step === "ask_code") {
      currentState.step = "confirm";
      const positiveWords = ["evet", "onay", "onayl\u0131yorum", "onayliyorum", "tamam", "tamamd\u0131r", "tamamdir", "olur", "g\xF6nder", "gonder", "\xE7a\u011F\u0131r", "cagir", "gelsin", "yolla"];
      const isPositive = positiveWords.some((w) => lower.includes(w));
      if (isPositive) {
        shouldCreateOrder = true;
        currentState.step = "completed";
        replyText = "Sipari\u015Finiz olu\u015Fturuldu, en yak\u0131n kuryemiz hemen y\xF6nlendirildi. Sizi m\xFC\u015Fteri panelinize aktar\u0131yorum, iyi g\xFCnler dilerim!";
      } else {
        replyText = 'Anlad\u0131m. De\u011Fi\u015Ftirmek istedi\u011Finiz bilgiyi s\xF6yleyebilir ya da onayl\u0131yorsan\u0131z "Evet" diyebilirsiniz.';
      }
    } else {
      replyText = "Sipari\u015Finiz ba\u015Far\u0131yla al\u0131nd\u0131. Yeni bir kurye talebi i\xE7in diledi\u011Finiz zaman bana seslenebilirsiniz.";
    }
    const sanitized = cleanCustomerServiceSpeech(replyText, currentState.step);
    replyText = sanitized.text;
    if (sanitized.step) {
      currentState.step = sanitized.step;
    }
    res.json({
      success: true,
      replyText,
      state: currentState,
      shouldCreateOrder
    });
  } catch (err) {
    console.error("[AI VOICE CHAT ERROR]", err);
    res.status(500).json({ error: err.message || "Sesli asistan hatas\u0131" });
  }
});
app.post("/api/ai-voice/send-code", async (req, res) => {
  try {
    const { email, code, orderSummary } = req.body || {};
    if (!email || !code) {
      return res.status(400).json({ error: "E-posta ve g\xFCvenlik kodu zorunludur." });
    }
    const cleanEmail = String(email).trim().toLowerCase();
    const cleanCode = String(code).trim();
    const subject = `Antalya Kurye - 4 Haneli G\xFCvenlik Kodunuz: ${cleanCode}`;
    const textContent = `Say\u0131n M\xFC\u015Fterimiz,

M\xFC\u015Fteri hizmetleri sesli asistan\u0131m\u0131z \xFCzerinden olu\u015Fturdu\u011Funuz kurye talebini onaylamak i\xE7in 4 haneli g\xFCvenlik kodunuz: ${cleanCode}

Bu kod 10 dakika s\xFCreyle ge\xE7erlidir.

Antalya \u015Eehir \u0130\xE7i Moto Kurye Teslimat 7/24`;
    const htmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 520px; margin: 0 auto; background: #021a14; color: #f8fafc; border-radius: 16px; border: 1px solid #059669; padding: 24px;">
        <div style="text-align: center; margin-bottom: 20px;">
          <h2 style="color: #34d399; margin: 0; font-size: 22px;">\u{1F6F5} Antalya Kurye</h2>
          <p style="color: #94a3b8; font-size: 13px; margin: 4px 0 0;">7/24 \u015Eehir \u0130\xE7i H\u0131zl\u0131 Moto Kurye Hizmeti</p>
        </div>
        <div style="background: #032d23; border: 1px solid #10b981; border-radius: 12px; padding: 20px; text-align: center; margin-bottom: 20px;">
          <p style="color: #a7f3d0; font-size: 14px; margin: 0 0 10px;">Sesli asistan kurye talebinizi onaylamak i\xE7in 4 haneli g\xFCvenlik kodunuz:</p>
          <div style="font-size: 38px; font-weight: 900; letter-spacing: 10px; color: #fbbf24; background: #011611; padding: 12px 24px; border-radius: 10px; display: inline-block; border: 2px dashed #f59e0b;">
            ${cleanCode}
          </div>
          <p style="color: #94a3b8; font-size: 12px; margin: 10px 0 0;">Bu kod 10 dakika s\xFCreyle ge\xE7erlidir.</p>
        </div>
        ${orderSummary ? `
        <div style="background: #011611; border-radius: 10px; padding: 14px; font-size: 13px; margin-bottom: 16px; color: #cbd5e1;">
          <div style="margin-bottom: 6px;"><strong style="color: #34d399;">\u{1F4CD} Al\u0131\u015F:</strong> ${orderSummary.pickup || "Belirtildi"}</div>
          <div style="margin-bottom: 6px;"><strong style="color: #fbbf24;">\u{1F3C1} Teslim:</strong> ${orderSummary.destination || "Belirtildi"}</div>
          <div><strong style="color: #a7f3d0;">\u{1F4B0} \xDCcret:</strong> ${orderSummary.price || 150} TL</div>
        </div>` : ""}
        <p style="font-size: 12px; color: #64748b; text-align: center; margin: 0;">Bu i\u015Flemi siz ba\u015Flatmad\u0131ysan\u0131z bu e-postay\u0131 dikkate almay\u0131n\u0131z.</p>
      </div>
    `;
    const senderUser = "kuryeantalyam@gmail.com";
    const senderPass = "tlnsrezkaobytsvg";
    const directTransporter = import_nodemailer.default.createTransport({
      host: "smtp.gmail.com",
      port: 465,
      secure: true,
      auth: { user: senderUser, pass: senderPass },
      tls: { rejectUnauthorized: false },
      connectionTimeout: 1e4
    });
    const info = await directTransporter.sendMail({
      from: `"Antalya \u015Eehir \u0130\xE7i Teslimat 7/24" <${senderUser}>`,
      to: cleanEmail,
      replyTo: "kuryeantalyam@gmail.com",
      subject,
      text: textContent,
      html: htmlContent,
      priority: "high"
    });
    console.log(`[AI VOICE CODE REAL DISPATCH] \u2705 Sent code ${cleanCode} to ${cleanEmail}. MessageId: ${info.messageId}`);
    return res.json({ success: true, message: `${cleanEmail} adresine 4 haneli g\xFCvenlik kodu g\xF6nderildi.` });
  } catch (err) {
    console.error("[AI VOICE SEND CODE ERROR]", err?.message);
    return res.status(500).json({ error: "Kod g\xF6nderilemedi: " + err?.message });
  }
});
app.post("/api/ai-voice/create-order", (req, res) => {
  try {
    const { pickupAddress, pickupDistrict, destAddress, destDistrict, packageContent, phone, customerName, price = 150 } = req.body;
    if (!pickupAddress || !destAddress) {
      return res.status(400).json({ error: "Al\u0131m ve teslim adresleri zorunludur." });
    }
    const cleanFrom = pickupDistrict || detectAntalyaDistrict(pickupAddress);
    const cleanTo = destDistrict || detectAntalyaDistrict(destAddress);
    const cleanPhone = phone || "0500 000 00 00";
    const cleanName = customerName || "Sesli Asistan M\xFC\u015Fterisi";
    const randomSuffix = Math.floor(1e3 + Math.random() * 9e3);
    const orderId = `req-voice-${Date.now()}`;
    const trackingCode = `ANT-V${randomSuffix}`;
    const newRequest = {
      id: orderId,
      trackingCode,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      sender: {
        district: cleanFrom,
        neighborhood: "",
        addressDetail: pickupAddress,
        contactName: cleanName,
        contactPhone: cleanPhone,
        lat: 36.886,
        lng: 30.7065
      },
      receiver: {
        district: cleanTo,
        neighborhood: "",
        addressDetail: destAddress,
        contactName: "Al\u0131c\u0131",
        contactPhone: cleanPhone,
        lat: 36.8732,
        lng: 30.6384
      },
      packageType: "other",
      packageName: packageContent ? `Sesli Kurye: ${packageContent}` : "Sesli Asistan Acil Paket",
      packageWeightKg: 1,
      urgency: "express_vip",
      price: Number(price) || 150,
      courierEarnings: Number(price) || 150,
      paymentMethod: "gonderici_odemeli",
      isPaid: false,
      status: "pending_admin",
      noteForCourier: `[\u{1F399}\uFE0F Sesli Kurye Talebi] \u0130\xE7erik: ${packageContent || "Belirtilmedi"}. 30-45 Dk Acil Kurye. M\xFC\u015Fteri Tel: ${cleanPhone}`,
      estimatedDistanceKm: 10,
      estimatedDurationMins: 35
    };
    dbState.requests.unshift(newRequest);
    saveDatabase();
    if (serverFirestoreDb) {
      (0, import_firestore.setDoc)((0, import_firestore.doc)(serverFirestoreDb, "delivery_requests", newRequest.id), JSON.parse(JSON.stringify(newRequest)), { merge: true }).catch((e) => console.warn("[FIRESTORE VOICE ORDER ERR]", e.message));
    }
    res.json({
      success: true,
      message: "Sesli sipari\u015F ba\u015Far\u0131yla y\xF6netici onay\u0131na iletildi.",
      order: newRequest,
      trackingCode: newRequest.trackingCode
    });
  } catch (err) {
    console.error("[AI VOICE CREATE ORDER ERR]", err);
    res.status(500).json({ error: err.message || "Sipari\u015F olu\u015Fturulamad\u0131." });
  }
});
var ttsAudioCache = /* @__PURE__ */ new Map();
async function fetchGoogleTts(text) {
  const chunks = [];
  if (text.length <= 180) {
    chunks.push(text);
  } else {
    const parts = text.split(/(?<=[.?!,;:])\s+/);
    let cur = "";
    for (const p of parts) {
      if ((cur + " " + p).trim().length <= 180) {
        cur = (cur + " " + p).trim();
      } else {
        if (cur) chunks.push(cur);
        cur = p;
      }
    }
    if (cur) chunks.push(cur);
  }
  const buffers = await Promise.all(
    chunks.map(
      (chunk) => new Promise((resolve, reject) => {
        const url = "https://translate.google.com/translate_tts?ie=UTF-8&q=" + encodeURIComponent(chunk) + "&tl=tr&client=tw-ob";
        import_https.default.get(
          url,
          { headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" } },
          (res) => {
            if (res.statusCode !== 200) {
              return reject(new Error("Google TTS status " + res.statusCode));
            }
            const data = [];
            res.on("data", (c) => data.push(c));
            res.on("end", () => resolve(Buffer.concat(data)));
          }
        ).on("error", reject);
      })
    )
  );
  return Buffer.concat(buffers);
}
async function generateGeminiTtsAudio(text, voiceParam) {
  if (!geminiClient) return null;
  try {
    const voiceName = voiceParam === "female" ? "Kore" : "Fenrir";
    const response = await geminiClient.models.generateContent({
      model: "gemini-3.8-flash-lite-tts",
      contents: [
        {
          role: "user",
          parts: [
            {
              text,
              speechMetadata: {
                style: voiceParam === "female" ? "Warm, clear, and professional female Turkish customer service voice" : "Deep, clear, and professional male Turkish customer service voice"
              }
            }
          ]
        }
      ],
      config: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName }
          }
        }
      }
    });
    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      return {
        buffer: Buffer.from(base64Audio, "base64"),
        mimeType: "audio/wav"
      };
    }
  } catch (err) {
    console.debug("[GEMINI TTS] Fallback to secondary TTS engine:", err?.message);
  }
  return null;
}
async function generateEdgeTtsAudio(text, voiceName, pitch = "-8Hz", rate = "+6%") {
  const tmpId = `tts_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.mp3`;
  const tmpPath = import_path.default.join(import_os.default.tmpdir(), tmpId);
  try {
    const tts = new import_node_edge_tts.EdgeTTS({
      voice: voiceName,
      lang: "tr-TR",
      outputFormat: "audio-24khz-96kbitrate-mono-mp3",
      rate,
      pitch,
      timeout: 8e3
    });
    await tts.ttsPromise(text, tmpPath);
    const buf = await import_fs.default.promises.readFile(tmpPath);
    import_fs.default.promises.unlink(tmpPath).catch(() => {
    });
    return buf;
  } catch (err) {
    import_fs.default.promises.unlink(tmpPath).catch(() => {
    });
    console.debug("[EDGE TTS NOTICE] EdgeTTS unavailable (will use Google Neural TTS):", err?.message);
    return null;
  }
}
app.get("/api/ai-voice/tts", async (req, res) => {
  try {
    const rawText = String(req.query.text || "").trim();
    const voiceParam = String(req.query.voice || "").toLowerCase();
    const voiceName = voiceParam === "female" ? "tr-TR-EmelNeural" : "tr-TR-AhmetNeural";
    const pitch = voiceParam === "female" ? "+0Hz" : "-8Hz";
    const rate = voiceParam === "female" ? "+10%" : "+6%";
    if (!rawText) {
      return res.status(400).send("Text parameter is required");
    }
    let s = rawText;
    s = s.replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, "");
    s = s.replace(/[#*•_~`]/g, "");
    s = s.replace(/\bTL\b/gi, "lira");
    s = s.replace(/\btl\b/gi, "lira");
    s = s.replace(/\bDk\b/gi, "dakika");
    s = s.replace(/\bdk\b/gi, "dakika");
    s = s.replace(/\bCad\./gi, "Caddesi");
    s = s.replace(/\bMah\./gi, "Mahallesi");
    s = s.replace(/\bSok\./gi, "Soka\u011F\u0131");
    s = s.replace(/\bNo:\s*(\d+)/gi, "numara $1");
    s = s.replace(/ANT-V(\d+)/gi, (m, d) => "A N T V " + d.split("").join(" "));
    s = s.replace(/\s*,\s*/g, ", ");
    s = s.replace(/\s+/g, " ");
    const cleanSpeech = s.trim();
    if (!cleanSpeech) {
      return res.status(400).send("No speakable text");
    }
    const cacheKey = `${voiceName}:${pitch}:${rate}:${cleanSpeech.toLowerCase()}:v6_resilient`;
    if (ttsAudioCache.has(cacheKey)) {
      const cached = ttsAudioCache.get(cacheKey);
      res.setHeader("Content-Type", cached.mimeType);
      res.setHeader("Content-Length", cached.buffer.length);
      res.setHeader("Cache-Control", "public, max-age=604800, immutable");
      return res.send(cached.buffer);
    }
    let audioResult = null;
    if (geminiClient) {
      const geminiResult = await generateGeminiTtsAudio(cleanSpeech, voiceParam);
      if (geminiResult) {
        audioResult = geminiResult;
      }
    }
    if (!audioResult) {
      const edgeBuf = await generateEdgeTtsAudio(cleanSpeech, voiceName, pitch, rate);
      if (edgeBuf) {
        audioResult = { buffer: edgeBuf, mimeType: "audio/mpeg" };
      }
    }
    if (!audioResult) {
      const googleBuf = await fetchGoogleTts(cleanSpeech);
      if (googleBuf && googleBuf.length > 0) {
        audioResult = { buffer: googleBuf, mimeType: "audio/mpeg" };
      }
    }
    if (!audioResult) {
      throw new Error("All TTS generation providers returned empty audio");
    }
    if (ttsAudioCache.size > 300) {
      const firstKey = ttsAudioCache.keys().next().value;
      if (firstKey) ttsAudioCache.delete(firstKey);
    }
    ttsAudioCache.set(cacheKey, audioResult);
    res.setHeader("Content-Type", audioResult.mimeType);
    res.setHeader("Content-Length", audioResult.buffer.length);
    res.setHeader("Cache-Control", "public, max-age=604800, immutable");
    res.send(audioResult.buffer);
  } catch (err) {
    console.warn("[AI VOICE TTS NOTICE] Using fallback synthesis:", err?.message);
    try {
      const emergencyBuf = await fetchGoogleTts("Tamam, sizi dinliyorum.");
      res.setHeader("Content-Type", "audio/mpeg");
      res.setHeader("Content-Length", emergencyBuf.length);
      return res.send(emergencyBuf);
    } catch {
      res.status(200).json({ error: "TTS audio could not be generated" });
    }
  }
});
app.get(
  [
    "/api/download-customer-apk",
    "/downloads/Antalya-Kurye-Cagir.apk",
    "/downloads/antalya-kurye-cagir.apk",
    "/downloads/Antalya-Kurye-Cagir-PlayStore.apk"
  ],
  (req, res) => {
    const possiblePaths = [
      import_path.default.join(process.cwd(), "public", "downloads", "Antalya-Kurye-Cagir.apk"),
      import_path.default.join(process.cwd(), "dist", "downloads", "Antalya-Kurye-Cagir.apk")
    ];
    let apkPath = "";
    for (const p of possiblePaths) {
      if (import_fs.default.existsSync(p)) {
        apkPath = p;
        break;
      }
    }
    if (!apkPath) {
      return res.status(404).send("Antalya Kurye \xC7a\u011F\u0131r APK dosyas\u0131 haz\u0131rlan\u0131yor, l\xFCtfen birka\xE7 saniye sonra tekrar deneyiniz.");
    }
    res.setHeader("Content-Type", "application/vnd.android.package-archive");
    res.setHeader("Content-Disposition", 'attachment; filename="Antalya-Kurye-Cagir.apk"');
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Cache-Control", "public, max-age=0, must-revalidate");
    res.sendFile(apkPath);
  }
);
app.get("/api/customer-apk-info", (req, res) => {
  const apkPath = import_path.default.join(process.cwd(), "public", "downloads", "Antalya-Kurye-Cagir.apk");
  let sizeMb = "0.30 MB";
  let exists = false;
  if (import_fs.default.existsSync(apkPath)) {
    exists = true;
    const stats = import_fs.default.statSync(apkPath);
    sizeMb = (stats.size / (1024 * 1024)).toFixed(2) + " MB";
  }
  res.json({
    success: true,
    name: "Antalya Kurye \xC7a\u011F\u0131r APK",
    packageName: "com.antalyakurye.cagir",
    version: "1.0.0",
    versionCode: 1,
    size: sizeMb,
    exists,
    downloadUrl: "/downloads/Antalya-Kurye-Cagir.apk",
    directApiUrl: "/api/download-customer-apk",
    playStoreReady: true,
    releaseDate: "2026-10-06",
    permissions: [
      "INTERNET (Canl\u0131 Kurye \xC7a\u011F\u0131rma ve Radar Takip)",
      "ACCESS_NETWORK_STATE (A\u011F Durumu Kontrol\xFC)",
      "POST_NOTIFICATIONS (Kurye Geldi ve Teslimat Durumu Bildirimleri)",
      "ACCESS_FINE_LOCATION (Tek Dokunu\u015Fla Adres ve Konum Bulma)",
      "VIBRATE (Durum G\xFCncelleme Titre\u015Fimi)"
    ]
  });
});
app.get(
  [
    "/api/download-admin-apk",
    "/downloads/Antalya-Yonetim.apk",
    "/downloads/antalya-yonetim.apk",
    "/downloads/Antalya-Kurye-Yonetim.apk"
  ],
  (req, res) => {
    const possiblePaths = [
      import_path.default.join(process.cwd(), "public", "downloads", "Antalya-Yonetim.apk"),
      import_path.default.join(process.cwd(), "dist", "downloads", "Antalya-Yonetim.apk")
    ];
    let apkPath = "";
    for (const p of possiblePaths) {
      if (import_fs.default.existsSync(p)) {
        apkPath = p;
        break;
      }
    }
    if (!apkPath) {
      return res.status(404).send("Y\xF6netim APK dosyas\u0131 haz\u0131rlan\u0131yor, l\xFCtfen birka\xE7 saniye sonra tekrar deneyiniz.");
    }
    res.setHeader("Content-Type", "application/vnd.android.package-archive");
    res.setHeader("Content-Disposition", 'attachment; filename="Antalya-Yonetim.apk"');
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Cache-Control", "public, max-age=0, must-revalidate");
    res.sendFile(apkPath);
  }
);
app.get("/api/admin-apk-info", (req, res) => {
  const apkPath = import_path.default.join(process.cwd(), "public", "downloads", "Antalya-Yonetim.apk");
  let sizeMb = "0.29 MB";
  let exists = false;
  if (import_fs.default.existsSync(apkPath)) {
    exists = true;
    const stats = import_fs.default.statSync(apkPath);
    sizeMb = (stats.size / (1024 * 1024)).toFixed(2) + " MB";
  }
  res.json({
    success: true,
    name: "Antalya Kurye Y\xF6netim APK",
    version: "1.5.0",
    versionCode: 15,
    size: sizeMb,
    exists,
    downloadUrl: "/downloads/Antalya-Yonetim.apk",
    directApiUrl: "/api/download-admin-apk",
    releaseDate: "2026-09-30",
    permissions: [
      "POST_NOTIFICATIONS (Anl\u0131k Y\xF6netici Onay Bildirimi)",
      "VIBRATE (Acil Talep Titre\u015Fimi)",
      "WAKE_LOCK (Ekran Kapal\u0131yken Sesli \xC7a\u011Fr\u0131 ve Uyanma)",
      "INTERNET (7/24 Kesintisiz Y\xF6netim Senkronizasyonu)"
    ]
  });
});
app.get(
  [
    "/api/download-apk",
    "/downloads/Antalya-Kurye-Talep-Havuzu.apk",
    "/downloads/antalya-kurye-talep-havuzu.apk"
  ],
  (req, res) => {
    const possiblePaths = [
      import_path.default.join(process.cwd(), "public", "downloads", "Antalya-Kurye-Talep-Havuzu.apk"),
      import_path.default.join(process.cwd(), "dist", "downloads", "Antalya-Kurye-Talep-Havuzu.apk")
    ];
    let apkPath = "";
    for (const p of possiblePaths) {
      if (import_fs.default.existsSync(p)) {
        apkPath = p;
        break;
      }
    }
    if (!apkPath) {
      return res.status(404).send("APK dosyas\u0131 haz\u0131rlan\u0131yor, l\xFCtfen birka\xE7 saniye sonra tekrar deneyiniz.");
    }
    res.setHeader("Content-Type", "application/vnd.android.package-archive");
    res.setHeader("Content-Disposition", 'attachment; filename="Antalya-Kurye-Talep-Havuzu.apk"');
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Cache-Control", "public, max-age=0, must-revalidate");
    res.sendFile(apkPath);
  }
);
app.get(
  [
    "/api/download-zip",
    "/downloads/Antalya-Kurye-Uygulama.zip",
    "/downloads/antalya-kurye-uygulama.zip"
  ],
  (req, res) => {
    const possiblePaths = [
      import_path.default.join(process.cwd(), "public", "downloads", "Antalya-Kurye-Uygulama.zip"),
      import_path.default.join(process.cwd(), "dist", "downloads", "Antalya-Kurye-Uygulama.zip")
    ];
    let zipPath = "";
    for (const p of possiblePaths) {
      if (import_fs.default.existsSync(p)) {
        zipPath = p;
        break;
      }
    }
    if (!zipPath) {
      return res.status(404).send("ZIP paketi haz\u0131rlan\u0131yor, l\xFCtfen birka\xE7 saniye sonra tekrar deneyiniz.");
    }
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", 'attachment; filename="Antalya-Kurye-Uygulama.zip"');
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Cache-Control", "public, max-age=0, must-revalidate");
    res.sendFile(zipPath);
  }
);
app.get("/api/apk-info", (req, res) => {
  const apkPath = import_path.default.join(process.cwd(), "public", "downloads", "Antalya-Kurye-Talep-Havuzu.apk");
  let sizeMb = "0.12 MB";
  let exists = false;
  if (import_fs.default.existsSync(apkPath)) {
    exists = true;
    const stats = import_fs.default.statSync(apkPath);
    sizeMb = (stats.size / (1024 * 1024)).toFixed(2) + " MB";
  }
  res.json({
    success: true,
    name: "Antalya Kurye Talep Havuzu",
    version: "1.3.0",
    versionCode: 13,
    size: sizeMb,
    exists,
    downloadUrl: "/downloads/Antalya-Kurye-Talep-Havuzu.apk",
    directApiUrl: "/api/download-apk",
    releaseDate: "2026-09-26",
    permissions: [
      "POST_NOTIFICATIONS (Anl\u0131k Yeni Talep Bildirimi)",
      "VIBRATE (Acil \xC7a\u011Fr\u0131 Titre\u015Fimi)",
      "WAKE_LOCK (Ekran Kapal\u0131yken Bildirim Alma)",
      "ACCESS_FINE_LOCATION (Haritada Canl\u0131 Konum Takibi)",
      "INTERNET (7/24 Kesintisiz Sunucu & Havuz Senkronizasyonu)"
    ]
  });
});
var viteServerInstance = null;
var viteInitPromise = process.env.NODE_ENV !== "production" ? (0, import_vite.createServer)({
  server: { middlewareMode: true },
  appType: "spa"
}).then((vite) => {
  viteServerInstance = vite;
  console.log("[VITE] Vite dev middleware loaded and active.");
  return vite;
}).catch((err) => {
  console.error("[VITE INIT ERROR]", err);
  return null;
}) : null;
if (process.env.NODE_ENV !== "production") {
  app.use(async (req, res, next) => {
    try {
      if (req.method !== "GET" && req.method !== "HEAD" && !req.path.startsWith("/api")) {
        return res.redirect(303, "/");
      }
      if (viteServerInstance) {
        return viteServerInstance.middlewares(req, res, next);
      }
      const vite = await viteInitPromise;
      if (vite) {
        return vite.middlewares(req, res, next);
      }
      next();
    } catch (err) {
      next(err);
    }
  });
} else {
  const distPath = import_path.default.join(process.cwd(), "dist");
  app.use(import_express.default.static(distPath));
  app.all("*", (req, res) => {
    if (req.method !== "GET" && req.method !== "HEAD" && !req.path.startsWith("/api")) {
      return res.redirect(303, "/");
    }
    res.sendFile(import_path.default.join(distPath, "index.html"));
  });
}
var server = app.listen(PORT, "0.0.0.0", () => {
  console.log(`[SERVER] Antalya Kurye Express server running on port ${PORT}`);
});
server.on("error", (err) => {
  if (err && err.code === "EADDRINUSE") {
    console.warn(`[SERVER WARNING] Port ${PORT} temporarily busy, retrying in 1000ms...`);
    setTimeout(() => {
      try {
        server.close();
      } catch {
      }
      server.listen(PORT, "0.0.0.0");
    }, 1e3);
    return;
  }
  console.error("[SERVER ERROR]", err);
});
process.on("SIGTERM", () => {
  console.log("[SERVER] SIGTERM received, closing server...");
  try {
    server.close(() => process.exit(0));
  } catch {
    process.exit(0);
  }
});
process.on("SIGINT", () => {
  console.log("[SERVER] SIGINT received, closing server...");
  try {
    server.close(() => process.exit(0));
  } catch {
    process.exit(0);
  }
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  MAX_ORDER_EMAIL_AGE_MS,
  getOrderNotificationRecipients,
  isTestOrFakeOrder,
  maskEmailAddress,
  maskEmailCustomerName,
  maskEmailPhoneNumber
});
//# sourceMappingURL=server.cjs.map
