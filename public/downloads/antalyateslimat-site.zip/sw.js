/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "8ba63c09e6273accf441fc7fbc49f5c2"
  }, {
    "url": "pwa-512x512.png",
    "revision": "8ba63c09e6273accf441fc7fbc49f5c2"
  }, {
    "url": "pwa-192x192.png",
    "revision": "281e61302493321f0c45f534bde14089"
  }, {
    "url": "index.html",
    "revision": "171cd3e0181c690152fe8a3c31d8cf86"
  }, {
    "url": "google1ef8290a0908c9ac.html",
    "revision": "1af1946053f3fff286b65b6298e7b2dc"
  }, {
    "url": "favicon.png",
    "revision": "6ba39719be6bb13b0116e64388b42fc2"
  }, {
    "url": "favicon.ico",
    "revision": "6146256dc7fb8aed42c2d65a7370ac12"
  }, {
    "url": "customer-app-logo.png",
    "revision": "f3d44d3cc0dff8e4702618f332d1a1ef"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "82ae77a45115dfb4d48cee7d7bae58e6"
  }, {
    "url": "app-logo.png",
    "revision": "8ba63c09e6273accf441fc7fbc49f5c2"
  }, {
    "url": "assets/index-kYNPtlAe.css",
    "revision": null
  }, {
    "url": "assets/index-C8LA39xZ.js",
    "revision": null
  }, {
    "url": "assets/aistudio/google1ef8290a0908c9ac_bdf4379b.html",
    "revision": null
  }, {
    "url": "app-logo.png",
    "revision": "8ba63c09e6273accf441fc7fbc49f5c2"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "82ae77a45115dfb4d48cee7d7bae58e6"
  }, {
    "url": "favicon.ico",
    "revision": "6146256dc7fb8aed42c2d65a7370ac12"
  }, {
    "url": "favicon.png",
    "revision": "6ba39719be6bb13b0116e64388b42fc2"
  }, {
    "url": "pwa-192x192.png",
    "revision": "281e61302493321f0c45f534bde14089"
  }, {
    "url": "pwa-512x512.png",
    "revision": "8ba63c09e6273accf441fc7fbc49f5c2"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "8ba63c09e6273accf441fc7fbc49f5c2"
  }, {
    "url": "manifest.webmanifest",
    "revision": "4f032a39bd05d50128d38b646074a74d"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
